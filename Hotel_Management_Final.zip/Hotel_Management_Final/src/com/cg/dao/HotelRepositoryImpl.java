package com.cg.dao;




import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;















import com.cg.entity.BookingDetails;
import com.cg.entity.Days;
import com.cg.entity.Hotel;
import com.cg.entity.RoomDetails;
import com.cg.entity.Users;



@Repository
public class HotelRepositoryImpl implements HotelRepository{
	
@PersistenceContext
private EntityManager entityManager;



@Override
public Users save(Users user) {
	entityManager.persist(user);
	entityManager.flush();
	return user;
}



@Override
public int save(Days booking,String strdate,String strdate2,String hotelid1,String roomid1,String userid1,int days1) {
	String q=" select b.per_night_rate from RoomDetails b where b.room_id=:pid ";
	TypedQuery<Integer> query=entityManager.createQuery(q,Integer.class);
	query.setParameter("pid", roomid1);
	int i=query.getSingleResult();
	int totalamount= i*days1;
	BookingDetails boo=new BookingDetails(roomid1,userid1,strdate,strdate2,booking.getNo_of_adults(),booking.getNo_of_children(),totalamount,hotelid1);
	
	entityManager.persist(boo);
	entityManager.flush();
	
	
	/*String s=" select b.booking_id from BookingDetails b where b.user_id=:puserid ";
	TypedQuery<Integer> query1=entityManager.createQuery(s,Integer.class);
	query1.setParameter("puserid",userid1);
	int id=query1.getSingleResult();
	return id;*/
	/*String s=" select b.booking_id from BookingDetails b where b.user_id=:puserid ";
	TypedQuery<Integer> query1=entityManager.createQuery(s,Integer.class);
	query1.setParameter("puserid",userid1);
	int id=query1.getSingleResult();*/
	return 1;
}






@Override
public Users check(Users user) {

	String q="select b from Users b where b.user_id=:pname and b.password=:ppass";
	TypedQuery<Users> query=entityManager.createQuery(q,Users.class);
	query.setParameter("pname", user.getUser_id());
	query.setParameter("ppass",user.getPassword());

try{
	Users a=query.getSingleResult();
	return a;
}
catch(NoResultException e){
	Users a=null;
return a;
}
}



@Override
public List<Hotel> loadAllhotels() {
	TypedQuery<Hotel> query=entityManager.createQuery("SELECT h FROM Hotel h",Hotel.class);
	return query.getResultList();
	
}



@Override
public List<RoomDetails> loadAllrooms(String id) {
	String q="SELECT b FROM RoomDetails b WHERE b.hotel_id=:pname";
	TypedQuery<RoomDetails> query=entityManager.createQuery(q,RoomDetails.class);
	query.setParameter("pname",id);
	return query.getResultList();
}



@Override
public List<BookingDetails> bookingstatus(String userid1, String hotelid1,
		String roomid1) {
	String p=" select b from BookingDetails b where b.user_id=:puserid ";
	TypedQuery<BookingDetails> query1=entityManager.createQuery(p,BookingDetails.class);
	query1.setParameter("puserid",userid1);
	
	
	return query1.getResultList();
}

//------------------------ADMIN----------------------------------


@Override
public List<Hotel> viewAllHotels() {
	TypedQuery<Hotel>query=entityManager.createQuery("SELECT h FROM Hotel h",Hotel.class);
	return query.getResultList();
}

@Override
public List<RoomDetails> viewRooms(String hid) {
	//String qry = "SELECT r FROM RoomDetails r WHERE r.hotel_id=:phid";
	TypedQuery<RoomDetails> query=entityManager.createQuery("SELECT r FROM RoomDetails r WHERE r.hotel_id=:phid",RoomDetails.class);
	//String h1 = hid.toString();
	//System.out.println("dshbfjh");
	query.setParameter("phid",hid);
	//List<RoomDetails> rl = query.getResultList();
	//System.out.println(hid+" is Hotel Id");
	
	//List<RoomDetails> rl=(List<RoomDetails>) query.setParameter("phid", hid);
	//System.out.println(rl);
	//List<RoomDetails> rl = query.getResultList();
	//System.out.println(rl.isEmpty());
	return query.getResultList();
}

@Override
public Hotel addHotels(Hotel hotel) {
	entityManager.persist(hotel);
	entityManager.flush();
	return hotel;
}

@Override
public boolean hotelCheck(String hid) {
	TypedQuery<Hotel> query=entityManager.createQuery("SELECT h FROM Hotel h WHERE h.hotel_id=:phid",Hotel.class);
	query.setParameter("phid",hid);
	Hotel h1=null;
	try{
		h1=query.getSingleResult();
	}
	catch(NoResultException e){
		return false;
	}
	//Hotel h1=query.getSingleResult();
	//System.out.println(h1);
	if(h1!=null)
	return true;
	else
		return false;
}

@Override
public List<BookingDetails> viewAllBookings(String hid) {
	TypedQuery<BookingDetails> query=entityManager.createQuery("SELECT b FROM BookingDetails b WHERE b.hotel_id=:phid",BookingDetails.class);
	query.setParameter("phid",hid);
	return query.getResultList();
}

@Override
public Hotel getHotelById(String hid) {
	TypedQuery<Hotel> query =entityManager.createQuery("SELECT h FROM Hotel h WHERE h.hotel_id=:phid",Hotel.class);
	query.setParameter("phid",hid);
	return query.getSingleResult();
}

@Override
public int updateHotel(String hotId, Hotel hdummy,String cityupd,String name, String address, String desc, double rate, String phone1, String phone2, String rating, String email, String fax) {
	String qry = "UPDATE Hotel h SET h.city=:pcity,h.hotel_name=:pname,h.address=:padd,h.description=:pdes,h.avg_rate_per_night=:pavg,"
			+ "h.phone_no1=:pno1,h.phone_no2=:pno2,h.rating=:prat,h.email=:pemail,h.fax=:pfax WHERE h.hotel_id=:phid";
	//String qry = "UPDATE Hotel h SET h.city=:pcity,h.hotel_name=:pname,h.address=:WHERE h.hotel_id=:phid";
		Query query=entityManager.createQuery(qry);
		query.setParameter("phid", hotId);
		query.setParameter("pcity", cityupd);
		query.setParameter("pname",name);
		query.setParameter("padd",address);		
		query.setParameter("pdes",desc);		
		query.setParameter("pavg", rate);
		query.setParameter("pno1", phone1);
		query.setParameter("pno2", phone2);
		query.setParameter("prat",rating);		
	    query.setParameter("pemail", email);
		query.setParameter("pfax",fax);
		
	return query.executeUpdate();
}

@Override
public int deleteHotel(String hid) {
	String qry = "DELETE FROM Hotel h WHERE h.hotel_id=:phid";
	Query query=entityManager.createQuery(qry);
	query.setParameter("phid", hid);
	return query.executeUpdate();
}

@Override
public int deleteRoomByHotelId(String hid) {
	String qry = "DELETE FROM RoomDetails r WHERE r.hotel_id=:phid";
	Query query=entityManager.createQuery(qry);
	query.setParameter("phid", hid);
	return query.executeUpdate();
}

@Override
public boolean roomcheck(String rid) {
	TypedQuery<RoomDetails> query=entityManager.createQuery("SELECT r FROM RoomDetails r WHERE r.room_id=:phid",RoomDetails.class);
	query.setParameter("phid",rid);
	RoomDetails h1=null;
	try{
		h1=query.getSingleResult();
	}
	catch(NoResultException e){
		return false;
	}
	if(h1!=null)
	return true;
	else
		return false;
}

@Override
public RoomDetails addrooms(RoomDetails room) {
	entityManager.persist(room);
	entityManager.flush();
	return room;
}

@Override
public List<RoomDetails> viewAllRooms() {
	TypedQuery<RoomDetails>query=entityManager.createQuery("SELECT r FROM RoomDetails r",RoomDetails.class);
	return query.getResultList();
}

@Override
public RoomDetails getRoomById(String rid) {
	TypedQuery<RoomDetails> query = entityManager.createQuery("SELECT r FROM RoomDetails r WHERE r.room_id=:pid", RoomDetails.class);
	query.setParameter("pid", rid);
	return query.getSingleResult();
}



@Override
public int updateRooms(String rid, int avail, String rno, String rtype,float rate) {
	String qry = "UPDATE RoomDetails r SET r.room_no=:prno,r.availability=:pavail,r.per_night_rate=:prate,"
			+ "r.room_type=:ptype WHERE r.room_id=:prid";
	Query query=entityManager.createQuery(qry);
	query.setParameter("prid", rid);
	query.setParameter("prno", rno);
	query.setParameter("pavail", avail);
	query.setParameter("prate", rate);
	query.setParameter("ptype", rtype);
	return query.executeUpdate();
}

@Override
public int deleteroom(String rid) {
	String qry = "DELETE FROM RoomDetails r WHERE r.room_id=:phid";
	Query query=entityManager.createQuery(qry);
	query.setParameter("phid", rid);
	return query.executeUpdate();
}

@Override
public List<BookingDetails> getBookingsByDate(String date) {
	TypedQuery<BookingDetails> query=entityManager.createQuery("SELECT b FROM BookingDetails b WHERE b.booked_from=:phid",BookingDetails.class);
	query.setParameter("phid",date);
	return query.getResultList();
}









}


