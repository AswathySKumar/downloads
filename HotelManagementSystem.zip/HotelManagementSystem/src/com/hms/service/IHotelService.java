package com.hms.service;

import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelService {

	public abstract boolean login(String user_id, String password) throws HotelException;

	public abstract void availrooms() throws HotelException;

	public abstract void bookingstatus() throws HotelException;



	public abstract int register(UserBean ub) throws HotelException;

}
