package com.hms.service;

import com.hms.bean.UserBean;
import com.hms.dao.HotelDaoImpl;
import com.hms.dao.IHotelDao;
import com.hms.exception.HotelException;

public class HotelServiceImpl implements IHotelService{
	IHotelDao hdao=new HotelDaoImpl();;

	@Override
	public boolean login(String user_id, String password) throws HotelException {
	boolean status=hdao.login(user_id, password);
		return status;
	}

	@Override
	public void availrooms() throws HotelException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bookingstatus() throws HotelException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int register(UserBean ub) throws HotelException{
		int status=hdao.register(ub);
		return status;
	}

	



}
