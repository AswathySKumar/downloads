package com.hms.ui;

import java.util.Scanner;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

public class HotelClient {
	private static String user_id;
	private static String password;
	static Scanner scan=null;
	static IHotelService serv=null;
	
	static HotelBean hb=null;
	static UserBean ub=null;
//	static RoomDetailsBean rdb=null;
	static BookingBean bb=null;
	
public static void main(String[] args) throws HotelException {
	scan= new Scanner(System.in);
	System.out.println("Welcome to HOLIDAYINN");
	System.out.println("1.Login or Register");
	System.out.println("2.Book room");
	System.out.println("3.Show booking status");
	System.out.println("4. Exit");
	int option=scan.nextInt();
	switch(option){
	case 1:
		System.out.println("1. Login \n2. Register");
		int reg=scan.nextInt();
		switch(reg) {	
		case 1:
		
				login();
				break;
		case 2:
	
				register();
				break;
		
		default:
				System.out.println("Option not found. please try again...");
				
	}
	break;
	
	case 2:
				System.out.println(" Rooms available are :");
				serv.availrooms();
				break;
				
	case 3:
				System.out.println("Please Login to continue...");
				login();
				break;
	case 4:
				System.exit(0); break;
	default:
				System.out.println(" Invalid option.");
	
	}
	

}
private static void register () throws HotelException{

	System.out.println("Enter userid ");
	user_id=scan.next();
	System.out.println("Enter password ");
	 password=scan.next();

		System.out.println("Enter your role");
		String role = scan.next();
		System.out.println("Enter username");
		 String username = scan.next();

			System.out.println("Enter mobilenumber ");
			String mblnum = scan.next();
			System.out.println("Enter alternate phone ");
			 String ph = scan.next();

				System.out.println("Enter address ");
				String add = scan.next();
				System.out.println("Enter email ");
				 String email = scan.next();
			
				ub=new UserBean(user_id, password, role, username, mblnum, ph, add, email);
				 
			 try{
				 serv=new HotelServiceImpl();
				int status= serv.register(ub);
				if(status>0) {
					System.out.println("Registration successful. Please login to continue..");
					login();
				}
				else {
					System.out.println("Error occured while registering...");
				}
				
			 }catch(Exception e) {
				 System.out.println(e.getMessage());
			 }
	
}
private static void login() throws HotelException {
	
	System.out.println("please enter your id ");
	user_id=scan.next();
	System.out.println("please enter your password ");
	 password=scan.next();
	 
	 serv= new HotelServiceImpl();
	 boolean status=serv.login(user_id,password);
	if(status==true){
	System.out.println("Log in successful");
		System.out.println(" 1. Check room Availability\n 2. Check Booking Status ");	
		int option1=scan.nextInt();
		switch (option1) {
		case 1: 
			serv.availrooms();
			
			break;
			
		case 2: 
			serv.bookingstatus();
			
			break;

		default:
			break;
		}
		
		
	}
	else{
		System.out.println(" Credentials not found, Please enter correct details or register again ");
	}
}
}
