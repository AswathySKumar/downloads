package com.hms.dao;

public interface IQueryMapper {
	public static final String Login_QRY="select * from users where user_id=? and password=?";
	public static final String Insert_QRY="insert into users values(?,?,?,?,?,?,?,?)";
	/*public static final String selectall_QRY="SELECT * FROM asset";
	public static final String id_QRY="SELECT id FROM asset where empid='?'";*/

}
