package com.hms.dao;

import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelDao {

public abstract	boolean login(String user_id, String password) throws HotelException;

public abstract int register(UserBean ub) throws HotelException;

}
