package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.util.DbUtil;

public class HotelDaoImpl implements IHotelDao {
	Connection conn=null;

	@Override
	public boolean login(String user_id, String password) throws HotelException {
		String id=null, pass=null;
		conn=DbUtil.getDbConnection();
		try {
			String s=IQueryMapper.Login_QRY;	
			PreparedStatement pst=conn.prepareStatement(s);
			pst.setString(1,user_id);
			pst.setString(2,password);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
			 id=rs.getString("user_id");
			 pass=rs.getString("password");
			break;
			}
			if((id!=null)&&(pass!=null)) {
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			throw new HotelException("couldn't retrieve data from db  "+e.getMessage());
		}
	}

	@Override
	public int register(UserBean ub) throws HotelException {
		conn=DbUtil.getDbConnection();
		int status=0;
		try {
			String s1=IQueryMapper.Insert_QRY;	
			PreparedStatement pst=conn.prepareStatement(s1);
			pst.setString(1, ub.getUser_id());
			pst.setString(2, ub.getPassword());
			pst.setString(3, ub.getRole());
			pst.setString(4, ub.getUser_name());
			pst.setString(5, ub.getMobile_no());
			pst.setString(6, ub.getPhone());
			pst.setString(7, ub.getAddress());
			pst.setString(8, ub.getEmail());
			status=pst.executeUpdate();
			
		} catch (Exception e) {
			System.out.println(" Error Occured ");
		}
		
		return status;
	}
}
