package com.hms.ui;

import java.util.List;
import java.util.Scanner;
import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

public class HotelClient {
	
//-----------------VARIABLES--------------------------------------------------------	
	private static String user_id,hotelid;;
	private static String password;
	static Scanner scan=new Scanner(System.in);
	static IHotelService serv=null;
	static boolean loggedin=false;
	static HotelBean hb=null;
	static UserBean ub=null;
	static int i;
	static BookingBean bb=null;
//==========================PROGRAM MAIN=============================================	
	public static void main(String[] args) throws HotelException {
	
		hotelmain();
	}
	
	
	
//==============================hotelmain()===============================================	
//----------------------------- Main Menu Function----------------------------------------
	public static void hotelmain() throws HotelException{
		scan= new Scanner(System.in);
		System.out.println("====== WELCOME TO HOTEL BOOKINGS MANAGEMENT SYSTEM =====");
		System.out.println("------------------------------------------------------");
		System.out.println("====== WELCOME TO CUSTOMER/HOTEL EMPLOYEE REGISTER/LOGIN FORM =======");
		System.out.println("1.Login or Register");
		System.out.println("2.Book room");
		System.out.println("3.Show booking status");
		System.out.println("4. Exit");
		int option=scan.nextInt();
		switch(option){
			case 1:
					System.out.println("1. Login \n2. Register");
						int reg=scan.nextInt();
						switch(reg) {	
							case 1:
									int i=login();
									if(i==1) {
										afterlogin();
									}
									break;
							case 2:
	
								register();
								break;
		
							default:
								System.out.println("Option not found. please try again...");
				
						}
						break;
	
			case 2:
					System.out.println(" Available Hotels :");
					hotel();
					break;
				
			case 3:
				
					bookingStatus();
					break;
			case 4:
					exitFunct();
					break;
			default:
					System.out.println(" Invalid option.");
	
	}// switch
	}// main function

//-------------------------USER REGISTRATION-----------------------------------------------------
	private static void register () throws HotelException{
		boolean result=false;
		String role;
		String username;
		String mblnum;
		String ph;
		String add;
		String email;

		serv=new HotelServiceImpl();
		boolean useridfound;
		do {
			do {
				System.out.println("Enter userid ");
				user_id=scan.next();
				result=serv.validateid(user_id);
			}while(result==false);
		
		useridfound=serv.useridcheck(user_id);	
		
		if(useridfound==true) {
			System.out.println("user id already exists try other");
		}else {
			break;
		}
		}while(useridfound==true);
		
	
		do {

			System.out.println("Enter password ");

			password=scan.next();

			result=serv.validatepassword(password);

			}while(result==false);

			do {

			System.out.println("Enter your role");

			role = scan.next();

			result=serv.validaterole(role);

			}while(result==false);

			do {

			System.out.println("Enter username");

			username = scan.next();

			result=serv.validateusername(username);

			}while(result==false);

			do {

			System.out.println("Enter mobilenumber ");

			mblnum = scan.next();

			result=serv.validatemobilenumber(mblnum);

			}while(result==false);

			do {

			System.out.println("Enter alternate phone ");

			ph = scan.next();

			result=serv.validatealternatenumber(ph);

			}while(result==false);

			do {

			System.out.println("Enter address ");

			add = scan.next();

			result=serv.validateaddress(add);

			}while(result==false);

			do {

			System.out.println("Enter email ");

			email = scan.next();

			result=serv.validateemail(email);

			}while(result==false);
			//System.out.println("Enter email ");
			//email = scan.next();
			
			
		ub=new UserBean(user_id, password, role, username, mblnum, ph, add, email);
				 
			try{
				
				int status= serv.register(ub);
				if(status>0) {
						System.out.println("Registration successful. Please login to continue..");
						int i=login();
						if(i==1) {
							afterlogin();
						
						}
						
					}
				else {
						System.out.println("Error occured while registering...");
					}
				
			}catch(Exception e) {
				System.out.println(e.getMessage());
			 }
	
	}//register method
//---------------------------------USER LOGIN ------------------------------------------------------------
	private static int login() throws HotelException {
		int i=0;
		 Scanner scan=new Scanner(System.in);
		System.out.println("please enter your id ");
		user_id=scan.next();
	
		System.out.println("please enter your password ");
		password=scan.next();
	 
		serv= new HotelServiceImpl();
		 boolean status=serv.login(user_id,password);
		 if(status==true){
			 System.out.println("Logged In");
			 i=1; loggedin=true;
		 }
		 else{
				System.out.println(" Credentials not found, Please enter correct details or register again ");
				System.out.println(" Do you want go back to main menu?\n 1. Main Menu\n 2.Exit ");
				int choice=scan.nextInt();
				switch (choice) {
				case 1:
						hotelmain();
					break;
				case 2:
					exitFunct();
						break;
				default:
					break;
				}
			}
			 
			 return i;
		}//login method
		 
	 
	 public static void afterlogin()throws HotelException {
		 
		 System.out.println(" 1. Check Hotel Rooms\n 2. Check Booking Status ");	
		 	int option1=scan.nextInt();
		 	switch (option1) {
		 		case 1: 
		 			hotel();
		 			break;
			
		 		case 2: 
		 			
		 			bookingStatus();
		 			break;

		 		default:
		 			System.out.println(" Enter Valid Option");
		 			break;
		}//switch
		
		
	}

//--------------------------------GET ALL HOTELS------------------------------------
public static void hotel() throws HotelException {
	serv=new HotelServiceImpl();
	List<HotelBean> hotelList=null;
	try {		
		hotelList = serv.AllHotel();
	} catch (Exception e) {
		
	System.out.println(e.getMessage());
	}

	for(HotelBean hb:hotelList)
	{
		System.out.println(hb);	
	}
	
	System.out.println("Choose an Option");
	System.out.println("1. Continue with Booking \n2. Exit\n");
	int choice=scan.nextInt();
	int exit=0;
	boolean hotelidfound=false;
	switch(choice) {
		case 1:
			do {
				System.out.println("Enter hotel Id");	
				hotelid=scan.next();
				hotelidfound=serv.hotelidcheck(hotelid);
					
					if(hotelidfound==true) {
						break;
					}else {
						System.out.println("room not found. Enter rooms only from the above List");
					}
					}while(hotelidfound==false);				
				availrooms(hotelid);
			break;
		
		case 2:
			exitFunct();
			break;
		
		default:
			System.out.println("Invalid Input");
	
	}

	
		
}

//----------------------- GET AVAILABLE ROOMS OF A HOTEL------------------------------------------------------
private static void availrooms(String hotelid) throws HotelException {
	
	serv=new HotelServiceImpl();
	List<RoomDetailsBean> rdbList=null;
	rdbList=serv.availrooms(hotelid);	
	for(RoomDetailsBean rdb:rdbList)
	{
		System.out.println(rdb);	
	}
	
	System.out.println("1. Continue with Booking \n2. Exit");
	int choice=scan.nextInt();
	
	switch(choice) {
	case 1:
		try {
			
			if(loggedin==false) {
				System.out.println(" You are not logged in.Please Login to Continue with booking..");
				int logincheck=login();
				if(logincheck==1) {
					booking();
				}
			}
			else if(loggedin==true)
				booking();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		break;
	case 2:
		exitFunct();
		break;
	}
	
	
}

//-------------------------------------BOOKING----------------------------------------------------------------
private static void booking() throws HotelException {
	serv=new HotelServiceImpl();
	boolean roomidfound=false;
	 String todate=null;
	 String roomid;
	 String fromdate;
	 int noofdays;
	 int noofchildren=0;
	 int noofadults=0;
	 boolean result=false;
	 do {
	System.out.println("enter room_id");
	roomid=scan.next();
	roomidfound=serv.getroomid(roomid);
	
	if(roomidfound==true) {
		break;
	}else {
		System.out.println("room not found. Enter rooms only from the above List");
	}
	}while(roomidfound==false);

	 
	 do {
		 do {
			 System.out.println("No of days Required");
			 noofdays=scan.nextInt();
			 result=serv.validateNoOfDays(noofdays);
		 }while(result==false);
	
		 if(noofdays>30) {
			 System.out.println("Sorry, You cannot book a hotel more than 30 days..");
		 }
	 }while(noofdays>30);
	serv.noofdays(user_id,noofdays,hotelid);
	
	do {
		System.out.println("booked_from");
		fromdate=scan.next();
		result=serv.validateDate(fromdate);
	}while(result==false);

			do {
			System.out.println("booked_to");
			todate=scan.next();
			result=serv.validateDate(fromdate);
			}while(result==false);
	do {	
	System.out.println("No of adults");
	noofadults=scan.nextInt();
	 result=serv.validateNoOfDays(noofdays);
	 }while(result==false);
	
	do {
	System.out.println("No of Children");
	noofchildren=scan.nextInt();
	 result=serv.validateNoOfDays(noofdays);
	}while(result==false);
	
	BookingBean bb= new BookingBean(roomid, fromdate, todate, noofadults, noofchildren);
	int i=serv.booking(bb);
	
	if(i>0) {
		System.out.println("Your Booking for room "+ roomid + " for Hotel id "+hotelid +" is Successful" );
		System.out.println("Your Booking id is " +serv.getbookingid());
	}else
		System.out.println("An error occured while Booking");
}


//---------------------------BOOKING STATUS------------------------------------
public static void bookingStatus() throws HotelException {
	serv=new HotelServiceImpl();
	/*if(loggedin==false) {
		System.out.println("Please Login to continue...");
		i=login();
		}	
	if(loggedin==true) 
	{
		System.out.println("Your Bookings are : \n");
		List<BookingBean> bookinglist=null;
		if(bookinglist==null) {
			System.out.println("You have no active bookings.");
		}else {
			bookinglist=serv.getAllBookings(user_id);	
			for(BookingBean bl:bookinglist)
			{
				System.out.println(bl);	
			}
		}
	}
	System.out.println("1. Do You want to search for any Bookings? \n2.exit");
	int choice=scan.nextInt();
	switch (choice) {
	case 1:
		search();
		break;
	case 2: 
		exitFunct();
		break;
	default:
		
		break;
	}*/

	/*public static void search() throws HotelException {*/
		System.out.println("Enter your Booking id");
		String bookingId=scan.next();
		
		BookingBean bb=serv.bookingStatus(bookingId);
		if(bb!=null) {
		System.out.println(bb.toString());}
		else {
			System.out.println(" No bookings found for this id ");
		}
		
		System.out.println(" Do you want go back to main menu?\n 1. Main Menu\n 2.Exit ");
		int choice=scan.nextInt();
		switch (choice) {
		case 1:
				hotelmain();
			break;
		case 2:
			exitFunct();
				break;
		default:
			break;
		}
		
}
	//}	
	//}

//==============================Exit=================================================
public static void exitFunct() {
	
	System.out.println(" Thank You for Using the Application  ");
	System.exit(0);
	
}





}