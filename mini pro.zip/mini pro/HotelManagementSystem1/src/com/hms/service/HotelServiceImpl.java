package com.hms.service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.dao.HotelDaoImpl;
import com.hms.dao.IHotelDao;
import com.hms.exception.HotelException;

public class HotelServiceImpl implements IHotelService{
	IHotelDao hdao=new HotelDaoImpl();;

	@Override
	public boolean login(String user_id, String password) throws HotelException {
	boolean status=hdao.login(user_id, password);
		return status;
	}

	

	@Override
	public BookingBean bookingStatus(String bookingId) throws HotelException {
		
		return hdao.bookingStatus(bookingId);
	}

	@Override
	public int register(UserBean ub) throws HotelException{
		int status=hdao.register(ub);
		return status;
	}

	@Override
	public List<HotelBean> AllHotel() {
	
		return hdao.Allhotel();
	}




	@Override
	public List<RoomDetailsBean> availrooms(String hotelid) throws HotelException {
		
		return hdao.availrooms(hotelid);
	}

/*	@Override
	public List<BookingBean> getAllBookings(String user_id) {
		
		return hdao.getAllBookings(user_id);
	}
	  */
	
	

	@Override
	public int booking(BookingBean bb) {
		int i=hdao.booking(bb);
		return i;
	}


	@Override
	public void noofdays(String user_id,int noofdays,String hotelid) throws HotelException {
		hdao.noofdays(user_id,noofdays,hotelid);
		
	}



	@Override
	public int getbookingid() throws  HotelException {
		int bookingid=hdao.getbookingid();
		return bookingid;
	}



	@Override
	public boolean useridcheck(String user_id) throws HotelException {
		boolean registerduserid=hdao.useridcheck(user_id);
		return registerduserid;
	}

	
	@Override
	public boolean getroomid(String roomid) {
		boolean roomidfound=hdao.getroomid(roomid);
		return roomidfound;
		
	}
	
	
	@Override
	public boolean hotelidcheck(String hotelid) {
		boolean hotelidfound=hdao.gethotelid(hotelid);
		return hotelidfound;
	}

	
	@Override

	public boolean validateid(String user_id) {

	Pattern pid= Pattern.compile("[0-9]{1,4}");

	Matcher mid=pid.matcher(user_id);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("only 4 numbers are allowed ");

	return false;

	}

	}

	@Override

	public boolean validatepassword(String password) {

	Pattern pass= Pattern.compile("[A-Za-z0-9@#&.]{4,7}");

	Matcher mid=pass.matcher(password);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("minimum 4 maximum 7 ");

	return false;

	}

	}


	@Override

	public boolean validaterole(String role) {

	Pattern rol= Pattern.compile("[A-Z][a-z]{1,20}");

	Matcher mid=rol.matcher(role);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum characters should be 10 ");

	return false;

	}

	}


	@Override

	public boolean validateusername(String username) {

	Pattern un= Pattern.compile("[A-Z][a-z]{3,20}");

	Matcher mid=un.matcher(username);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum allowed characters are 20 ");

	return false;

	}

	}

	@Override

	public boolean validatemobilenumber(String mblnum) {

	Pattern mb= Pattern.compile("[6-9]{1}[0-9]{9}");

	Matcher mid=mb.matcher(mblnum);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern number should be 10 digits ");

	return false;

	}

	}


	@Override

	public boolean validatealternatenumber(String ph) {

	Pattern p= Pattern.compile("[6-9]{1}[0-9]{9}");

	Matcher mid=p.matcher(ph);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern number should be 10 digits ");

	return false;

	}

	}

	@Override

	public boolean validateaddress(String add) {

	Pattern ad= Pattern.compile("[A-Za-z0-9.,]{5,25}");

	Matcher mid=ad.matcher(add);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum should be 25 ");

	return false;

	}

	}

  @Override

	public boolean validateemail(String email) {
  
	Pattern em= Pattern.compile("[a-zA-z0-9/_.%+-]+@[a-zA-z]+.[a-zA-Z]{2,15}$");

	Matcher mid=em.matcher(email);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern ");

	return false;

	}
  }

  
  
  public boolean validateDate(String date) {

		Pattern ad= Pattern.compile("[0-9]+-[a-zA-z]+-[0-9]{2,15}$");

		Matcher mid=ad.matcher(date);

		if(mid.matches()) {

		return true;

		}

		else {

		System.out.println("please follow the pattern DD-MMM-YYYY ");

		return false;

		}

		}



@Override
public boolean validateNoOfDays(int noofdays) {
	
	String str1 = Integer.toString(noofdays); 
	Pattern ad= Pattern.compile("[0-9]{1,3}$");

	Matcher mid=ad.matcher(str1);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern");

	return false;

	}

	
}






	}
