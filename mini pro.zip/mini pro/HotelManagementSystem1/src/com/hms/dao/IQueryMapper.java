package com.hms.dao;

public interface IQueryMapper {

	public static final String Login_QRY="select * from users where user_id=? and password=?";
	
	public static final String Insert_QRY="insert into users values(?,?,?,?,?,?,?,?)";
	
	public static final String BookingStatus_QRY="select * from BookingDetails where BOOKING_ID=?";
	
	public static final String Allhotel_QRY="select * from hotel";
	
	public static final String hotelroom_QRY=" select * from roomdetails where hotel_id=?";
	
	public static final String Booking_QRY="insert into bookingdetails values(hotelsequence.NEXTVAL,?,?,?,?,?,?,?,?)";
	
	public static final String rate_QRY=" select PER_NIGHT_RATE from roomdetails where ROOM_ID=? ";
	
	public static final String getBookingid_QRY=" select booking_id from bookingdetails where user_id=?";
	
	public static final String Useridcheck_QRY="select * from users where user_id=?";
	
	public static final String rromid_QRY="select * from roomdetails where room_id=?";
	
	public static final String hotelid_QRY="select * from hotel where hotel_id=?";
	
/*	public static final String getAllBookings_QRY="select * from bookingdetails where user_id=?";*/
}
