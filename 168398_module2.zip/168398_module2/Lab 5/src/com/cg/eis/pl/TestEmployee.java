package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.EmployeeException.EmployeeException;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmpService;

public class TestEmployee {
    
    static void validate(double Sal) throws EmployeeException{
        if(Sal<3000)
            throw new EmployeeException("Salary Should be Greater than 3000");
    }

    public static void main(String[] args) throws EmployeeException {
        Employee emp = new Employee();
        EmpService es = new EmpService();
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter Employee Name : ");
        String name =sc.next();
        System.out.println("Enter Employeee ID : ");
        int id = sc.nextInt();
        System.out.println("Enter Employee Designation : ");
        String desg = sc.next();
        System.out.println("Enter Employee Salary : ");
        double salary = sc.nextDouble();
        validate(salary);
        
        emp.setName(name);
        emp.setId(id);
        emp.setSalary(salary);
        emp.setDesg(desg);
        
        es.InsuranceScheme();
    
    sc.close();     
    }
    
}