package com.cg.eis.service;

public interface EmpServiceInterface {
    
    public void InsuranceScheme();
}