package lab_3_3;

public class TesterNoOfDaysMonthsYears {

    public static void main(String[] args) {

        NoOfDaysMonthsYears check = new NoOfDaysMonthsYears();
        check.TimePeriod();
        
    }

}