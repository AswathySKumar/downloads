package com.capgemini.javaclasslib.stringoperations;

public class AddStringitself {
    
	//Adding String to Itself
	
    public void AddStr(String str){
      
        String SelfConcat = str.concat(str);
        System.out.println("Entered String is : "+str);
        System.out.println("SelfConcated String : "+SelfConcat);
    }

}