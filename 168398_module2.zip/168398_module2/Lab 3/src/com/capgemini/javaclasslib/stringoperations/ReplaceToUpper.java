package com.capgemini.javaclasslib.stringoperations;

public class ReplaceToUpper {

    public void replaceToUpper(String str2){
    	
        int length = str2.length();
        
        String strUpper = str2.toUpperCase();
        for(int j=0;j<(length);j++)
        {
            if(j%2==0)
            {
                str2 = str2.replace(str2.charAt(j), strUpper.charAt(j));
            }
            
        }
        System.out.println("The Replaced String wth UpperCase is : "+str2);
}
}