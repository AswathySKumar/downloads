package lab_3_6;

public class TestAcceptZoned {

    public static void main(String[] args) {

        AcceptZoneId ZoneId = new AcceptZoneId();
        ZoneId.CalZoneId();
    }

}