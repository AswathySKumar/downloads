package lab_3_2;

import java.util.Scanner;

public class PosStrng {
    
    public void CheckStrng()
    {
        System.out.println("Enter String : \n");
        
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        sc.close();
        String str1 = str.toUpperCase();
        int length = str1.length();
        int count = 0;
        
        for(int j=0;j<(length-2);j++)
        {
            if(str1.charAt(j)>str1.charAt(j+1))
                {
                    count++;
                }
        
        }
        if(count==0)
            {
                System.out.println("\nEntered String is Positive Stirng");
            }
        else
            {
                System.out.println("\nEntered String is Negative String");
            }
    }

}