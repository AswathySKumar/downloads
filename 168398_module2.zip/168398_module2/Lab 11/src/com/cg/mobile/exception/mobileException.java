package com.cg.mobile.exception;

public class mobileException extends Exception{
	public mobileException() {
		
	}
	public mobileException(String str) {
		super(str);
	}

	
}
