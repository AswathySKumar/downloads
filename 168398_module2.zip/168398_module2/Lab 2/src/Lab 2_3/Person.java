package com.cg.JavaAssignmentLab2;
public class Person {
	private String fname;
	private String lname;
	private char gender;
	Person(String fname,String lname,char gender){
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
		System.out.println("Person Deatils"+"\n-----------"+"\nFirst Name: "+fname+"\nLast Name: "+lname+"\nGender: "+gender);
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}


}
