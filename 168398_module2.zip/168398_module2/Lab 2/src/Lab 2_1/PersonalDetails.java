package com.cg.JavaAssignmentLab2;

public class PersonalDetails {
	String fname;
	String lname;
	String gender;
	int  age;
	double weight;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonalDetails p=new PersonalDetails();
		p.fname="Divya";
		p.lname="Bharathi";
		p.gender="F";
		p.age=20;
		p.weight=85.55;
		System.out.println("Personal Details"+"\n---------");
		System.out.println("First Name: "+p.fname+"\nLast Name: "+p.lname+"\nGender: "+p.gender+"\nAge: "+p.age+"\nWeight: "+p.weight);
	}

}
