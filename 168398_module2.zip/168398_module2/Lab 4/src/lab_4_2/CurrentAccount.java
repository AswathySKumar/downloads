package lab_4_2;

import java.util.Scanner;

import lab_4_1.Account;

public class CurrentAccount extends Account {

    final static double OverDraftLimit = -2000.00;
    
    public double withdrawl(){
        if(OverDraftLimit < (Balance-Withdrawl)) {
        this.Balance = Balance - Withdrawl;
        System.out.println("Withdraw Amount : " + getWithdrawl());
        System.out.println("Updated Balance : " + Balance);
        }
        else{
            System.out.println("Statement : Over Draft Limit Exceeded");
            System.out.println("Current Balance : " + Balance);
        }
        return Balance;
    }

    
public static void main(String[] args) {
        
        Account person1 = new CurrentAccount();
        Account person2 = new CurrentAccount();
        Scanner sc = new Scanner(System.in);
        long accNumber1 = (long)(Math.random()*331656580+331656000);
        long accNumber2 = (long)(Math.random()*331656580+331656000);
        
        person1.setAccNumber(accNumber1);
        person2.setAccNumber(accNumber2);
        
        System.out.println("Enter Account Holder Name : ");
        String accHolder1 = sc.nextLine();
        person1.setAccHolder(accHolder1);
        
        System.out.println("Enter Account Holder Age : ");
        int age1 = sc.nextInt();
        person1.setAge(age1);

        System.out.println("Enter Balance Amount : ");
        double balance1 = sc.nextDouble();
        person1.setBalance(balance1);

        System.out.println("Enter Deposit Amount : ");
        double deposit = sc.nextDouble();
        person1.setDeposit(deposit);
        
        System.out.println("\nAccount Transactons ------->\n");
        person1.display();
        person1.deposit();
        
        System.out.println("\n-------------------------------------------\n");
        
        System.out.println("Enter Account Holder Name : ");
        String accHolder2 = sc.next();
        person2.setAccHolder(accHolder2);

        System.out.println("Enter Account Holder Age : ");
        int age2 = sc.nextInt();
        person2.setAge(age2);
        
        System.out.println("Enter Balance Amount : ");
        double balance2 = sc.nextDouble();
        person2.setBalance(balance2);
        
        System.out.println("Enter Withdrawl Amount : ");
        double withdrawl = sc.nextDouble();
        person2.setWithdrawl(withdrawl);

        System.out.println("\nAccount Transactons ------->\n");
        person2.display();
        person2.withdrawl();
        
        sc.close();
        }
}