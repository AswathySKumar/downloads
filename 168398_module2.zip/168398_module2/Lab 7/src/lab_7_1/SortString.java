package lab_7_1;

public class SortString {

    public static void main(String[] args) {

        String[] array = {"Pens","Perfume","Books","Bags","Clothes"};
        int size = array.length;
        System.out.println("List Before Sorting : \n");
        for(int i=0;i<size;i++){
            System.out.println(array[i]);
        }
        
        for(int i=0;i<size-1;i++){
            for(int j = i+1; j<array.length;j++){
                if(array[i].compareTo(array[j])>0){
                    String temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
        System.out.println("\nList After Sorting : \n");
        for(int i=0;i<size;i++){
            System.out.println(array[i]);
        }
        
    }

}