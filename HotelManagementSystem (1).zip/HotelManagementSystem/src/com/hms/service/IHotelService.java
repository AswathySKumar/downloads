package com.hms.service;

import java.sql.SQLException;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelService {

	public abstract boolean login(String user_id, String password) throws HotelException;

	public abstract BookingBean bookingStatus(String bookingId) throws HotelException;

	public abstract int register(UserBean ub) throws HotelException;

	public abstract List<HotelBean> AllHotel();

	public abstract List<RoomDetailsBean> availrooms(String hotelid) throws HotelException;

	public abstract int booking(BookingBean bb);

	public abstract void noofdays(String user_id,int noofdays,String hotelid) throws HotelException;

	public abstract int getbookingid() throws  HotelException;

	public abstract boolean useridcheck(String user_id)throws  HotelException;

	

	boolean validateemail(String email);

	boolean validateaddress(String add);

	boolean validatealternatenumber(String ph);

	boolean validatemobilenumber(String mblnum);

	boolean validateusername(String username);

	boolean validaterole(String role);

	boolean validatepassword(String password);

	boolean validateid(String user_id);

}
