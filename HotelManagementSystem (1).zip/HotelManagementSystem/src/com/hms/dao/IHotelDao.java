package com.hms.dao;

import java.sql.SQLException;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelDao {

public abstract	boolean login(String user_id, String password) throws HotelException;

public abstract int register(UserBean ub) throws HotelException;

public abstract BookingBean bookingStatus(String bookingId);

public abstract List<HotelBean> Allhotel();

public abstract List<RoomDetailsBean> availrooms(String hotelid) throws HotelException;

public abstract int booking(BookingBean bb);

public abstract void noofdays(String user_id,int noofdays,String hotelid) throws HotelException;

public abstract int getbookingid() throws HotelException;

public abstract boolean useridcheck(String user_id)throws HotelException;



}
