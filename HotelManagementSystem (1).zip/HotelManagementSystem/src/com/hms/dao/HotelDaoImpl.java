package com.hms.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.util.DbUtil;

public class HotelDaoImpl implements IHotelDao {
	
	Logger log=Logger.getRootLogger();
	Connection conn=null;
	static int noof_days;
	static String userid, hotel_id;
//====================================LOGIN==============================================
	@Override
	public boolean login(String user_id, String password) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		String id=null, pass=null;
		conn=DbUtil.getDbConnection();
		try {
				String s=IQueryMapper.Login_QRY;	
				PreparedStatement pst=conn.prepareStatement(s);
				pst.setString(1,user_id);
				pst.setString(2,password);
				ResultSet rs=pst.executeQuery();
				while(rs.next()) {
						id=rs.getString("user_id");
						pass=rs.getString("password");
						break;
				}
				if((id!=null)&&(pass!=null)) {
					log.info("credentials found.Authorised user");
					return true;
				}
				else 
					return false;
		} catch (SQLException e) {
			log.error("invalid user");
			throw new HotelException("couldn't retrieve data from db  "+e.getMessage());
		}
	}

//==================================== REGISTER =====================================================	
	
	@Override
	public int register(UserBean ub) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int status=0;
		
		try {
			String s1=IQueryMapper.Insert_QRY;	
			PreparedStatement pst=conn.prepareStatement(s1);
			pst.setString(1, ub.getUser_id());
			pst.setString(2, ub.getPassword());
			pst.setString(3, ub.getRole());
			pst.setString(4, ub.getUser_name());
			pst.setString(5, ub.getMobile_no());
			pst.setString(6, ub.getPhone());
			pst.setString(7, ub.getAddress());
			pst.setString(8, ub.getEmail());
			status=pst.executeUpdate();
			
		} catch (Exception e) {
			
				System.out.println(" Error Occured ");
		}
		
		return status;
	}

//===================================BOOKING STATUS==========================================
	
	@Override
	public BookingBean bookingStatus(String bookingId) {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		ResultSet rs=null;
		BookingBean bb=null;
		
		try {
			
			String s1=IQueryMapper.BookingStatus_QRY;	
			PreparedStatement pst=conn.prepareStatement(s1);
			pst.setString(1, bookingId);
			rs=pst.executeQuery();	
			while(rs.next()){
				bb= new BookingBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5),rs.getInt(6), rs.getInt(7), rs.getInt(8));	
				log.info("retrieved booking status");
			}
		}catch (Exception e) {
			System.out.println("Error occured while processing "+ e.getMessage());
			log.error("Error occured while processing bookingstatus");
		}
	
		return bb;
	}

//==================================GET ALL HOTELS================================================================	
	@Override
	public List<HotelBean> Allhotel() {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		List<HotelBean> hotelList=null;
		HotelBean hb=null;
		try {
		String s=IQueryMapper.Allhotel_QRY;
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(s);
		hotelList= new ArrayList<>();
		
		while(rs.next()) {
		
			hb=new HotelBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), 
					rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11));
			hotelList.add(hb);
			log.info("hotel details are retrieved");
		}
		
		}catch (Exception e) {
			System.out.println("Error occured " + e.getMessage());
			log.error("Error occured during hoteldetails retrieval");
		}
	
		return hotelList;
	}

//===============================GET AVAILABLE ROOMS========================================================
	@Override
	public List<RoomDetailsBean> availrooms(String hotelid) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		RoomDetailsBean rdb= null;
		List<RoomDetailsBean> rdbList=null;
		try {
			
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.hotelroom_QRY);
			pst.setString(1, hotelid);
			ResultSet rs=pst.executeQuery();
			rdbList= new ArrayList<>();
			while(rs.next()) {
				rdb= new RoomDetailsBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
				 rdbList.add(rdb);
				 log.info("room details retrieved");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			log.error("error occured during Room details retrieval");
			
		}
		
		return  rdbList;
	}

	
//===================================VARIBLE INITIALIZATION=========================================================
	
	

	@Override
	public void noofdays(String user_id,int noofdays,String hotelid) throws HotelException{
		PropertyConfigurator.configure("resources/log4j.properties");
			userid=user_id;
			noof_days=noofdays;	
			hotel_id=hotelid;
	}
	
//===================================USER ROOM BOOKING=========================================================
	@Override
	public int booking(BookingBean bb) {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int status=0; int room_amount=0;
	
		try {
			String roomid=bb.getRoom_id();
			PreparedStatement pst1=conn.prepareStatement(IQueryMapper.rate_QRY);
			pst1.setString(1, roomid);
			ResultSet rs=pst1.executeQuery();
			while(rs.next()) {
				room_amount=rs.getInt("PER_NIGHT_RATE"); break;
			}
		
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Booking_QRY);
			pst.setString(1,bb.getRoom_id());
			pst.setString(2,userid);		
			pst.setString(3, bb.getBooked_from());		
			pst.setString(4,  bb.getBoooked_to());			
			pst.setInt(5, bb.getNo_of_adults());			
			pst.setInt(6, bb.getNo_of_children());
			
			int totalamount= room_amount*noof_days;		
			pst.setInt(7, totalamount);	
			pst.setString(8,hotel_id);
			status=pst.executeUpdate();
			log.info("userdetails added successfully");
			
						
		} catch (Exception e) {
			System.out.println(e.getMessage());
			log.error("booking failed");
		}
		return status;
	}
	
//===================================GET BOOKING ID=========================================================

	@Override
	public int getbookingid() throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int bookingid=0;
		
		
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.getBookingid_QRY);
			pst.setString(1, userid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
			bookingid=rs.getInt("BOOKING_ID"); 
			break;
			
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return bookingid;
	
	}
	
	
//============================FOR CHECKING IF USERID ALREADY EXIST OR NOT=============================================	

	@Override
	public boolean useridcheck(String user_id) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		boolean useridfound=false;
		ResultSet rs=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Useridcheck_QRY);
			pst.setString(1, user_id);
			rs=pst.executeQuery();
			
			while(rs.next()) {
				useridfound=true;
				log.info("user id already exists");
				 break;
			}
					
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return useridfound;
	
	}

}
