package com.hms.ui;

import java.util.List;
import java.util.Scanner;
import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

public class HotelClient {
	
//-----------------VARIABLES--------------------------------------------------------	
	private static String user_id,hotelid;;
	private static String password;
	static Scanner scan=new Scanner(System.in);
	static IHotelService serv=null;
	static boolean loggedin=false;
	static HotelBean hb=null;
	static UserBean ub=null;
	static int i;
	static BookingBean bb=null;
//==========================PROGRAM MAIN=============================================	
	public static void main(String[] args) throws HotelException {
		scan= new Scanner(System.in);
		System.out.println("HOTEL BOOKINGS MANAGEMENT SYSTEM");
		System.out.println("1.Login or Register");
		System.out.println("2.Book room");
		System.out.println("3.Show booking status");
		System.out.println("4. Exit");
		int option=scan.nextInt();
		switch(option){
			case 1:
					System.out.println("1. Login \n2. Register");
						int reg=scan.nextInt();
						switch(reg) {	
							case 1:
		
									int i=login();
									if(i==1) {
										afterlogin();
									}
				
									break;
							case 2:
	
								register();
								break;
		
							default:
								System.out.println("Option not found. please try again...");
				
						}
						break;
	
			case 2:
					System.out.println(" Choose the Hotel :");
					hotel();
					break;
				
			case 3:
				
					bookingStatus();
				
					break;
			case 4:
					System.exit(0); break;
			default:
					System.out.println(" Invalid option.");
	
	}// switch
	

}//main
//-------------------------USER REGISTRATION-----------------------------------------------------
	private static void register () throws HotelException{
		boolean result=false;

		String role;

		String username;

		String mblnum;

		String ph;

		String add;

		String email;
		serv=new HotelServiceImpl();
		boolean useridfound;
		do {
			do {
				System.out.println("Enter userid ");
				user_id=scan.next();
				result=serv.validateid(user_id);
			}while(result==false);
		useridfound=serv.useridcheck(user_id);	
		if(useridfound==true) {
			System.out.println("user id already exists try other");
		}else {
			break;
		}
		}while(useridfound==true);
		
	
		do {

			System.out.println("Enter password ");

			password=scan.next();

			result=serv.validatepassword(password);

			}while(result==false);

			do {

			System.out.println("Enter your role");

			role = scan.next();

			result=serv.validaterole(role);

			}while(result==false);

			do {

			System.out.println("Enter username");

			username = scan.next();

			result=serv.validateusername(username);

			}while(result==false);

			do {

			System.out.println("Enter mobilenumber ");

			mblnum = scan.next();

			result=serv.validatemobilenumber(mblnum);

			}while(result==false);

			do {

			System.out.println("Enter alternate phone ");

			ph = scan.next();

			result=serv.validatealternatenumber(ph);

			}while(result==false);

			do {

			System.out.println("Enter address ");

			add = scan.next();

			result=serv.validateaddress(add);

			}while(result==false);

			do {

			System.out.println("Enter email ");

			email = scan.next();

			result=serv.validateemail(email);

			}while(result==false);
			
		ub=new UserBean(user_id, password, role, username, mblnum, ph, add, email);
				 
			try{
				
				int status= serv.register(ub);
				if(status>0) {
						System.out.println("Registration successful. Please login to continue..");
						login();
						afterlogin();
					}
				else {
						System.out.println("Error occured while registering...");
					}
				
			}catch(Exception e) {
				System.out.println(e.getMessage());
			 }
	
	}//register method
//---------------------------------USER LOGIN ------------------------------------------------------------
	private static int login() throws HotelException {
		int i=0;
		System.out.println("please enter your id ");
		user_id=scan.next();
	
		System.out.println("please enter your password ");
		password=scan.next();
	 
		serv= new HotelServiceImpl();
		 boolean status=serv.login(user_id,password);
		 if(status==true){
			 System.out.println("Logged In");
			 i=1; loggedin=true;
		 }
		 else{
				System.out.println(" Credentials not found, Please enter correct details or register again ");
			}
			 
			 return i;
		}//login method
		 
	 
	 public static void afterlogin()throws HotelException {
		 
		 System.out.println(" 1. Check Hotel Rooms\n 2. Check Booking Status ");	
		 	int option1=scan.nextInt();
		 	switch (option1) {
		 		case 1: 
		 			hotel();
			
		 			break;
			
		 		case 2: 
		 			bookingStatus();
			
		 			break;

		 		default:
		 			break;
		}//switch
		
		
	}
	

	

//--------------------------------GET ALL HOTELS------------------------------------
public static void hotel() throws HotelException {
	serv=new HotelServiceImpl();
	List<HotelBean> hotelList=null;
	try {		
		hotelList = serv.AllHotel();
	} catch (Exception e) {
		
		System.out.println(e.getMessage());
	}

	for(HotelBean hb:hotelList)
	{
		System.out.println(hb);	
	}
	
	System.out.println("Choose an Option");
	System.out.println("1. Continue with Booking \n2. Exit\n");
	int choice=scan.nextInt();
	int exit=0;
	//do {
	switch(choice) {
		case 1:
				System.out.println("Enter hotel Id");
				
				hotelid=scan.next();
				availrooms(hotelid);
			break;
		
		case 2:
			exit=1;
			System.exit(0);	
			break;
		
		default:
			System.out.println("Invalid Input");
	
	}
	//}while(exit==0);
	
		
}

//----------------------- GET AVAILABLE ROOMS OF A HOTEL------------------------------------------------------
private static void availrooms(String hotelid) throws HotelException {
	
	serv=new HotelServiceImpl();
	List<RoomDetailsBean> rdbList=null;
	rdbList=serv.availrooms(hotelid);
	for(RoomDetailsBean rdb:rdbList)
	{
		System.out.println(rdb);	
	}
	
	System.out.println("1. Continue with Booking \n2. Exit\n");
	int choice=scan.nextInt();
	
	switch(choice) {
	case 1:
		try {
			
			if(loggedin==false) {
				System.out.println(" Please Login to Continue with booking..");
				int logincheck=login();
				if(logincheck==1) {
					booking();
				}
			}
			else if(loggedin==true)
				booking();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		break;
	case 2:
		System.exit(0);
		break;
	}
	
	
}

//-------------------------------------BOOKING----------------------------------------------------------------
private static void booking() throws HotelException {
	serv=new HotelServiceImpl();
	
	 String todate;
	System.out.println("enter room_id");
	String roomid=scan.next();
	
	System.out.println("No of days Required");
	int noofdays=scan.nextInt();
	
	serv.noofdays(user_id,noofdays,hotelid);
	
	System.out.println("booked_from");
	String fromdate=scan.next();
	if(noofdays==1) {
		 todate=fromdate;
		 System.out.println("booked_to");
		 System.out.println(todate);
	}else {
		System.out.println("booked_to");
		todate=scan.next();
	}
	System.out.println("No of adults");
	int noofadults=scan.nextInt();
	
	System.out.println("No of Children");
	int noofchildren=scan.nextInt();
	
	BookingBean bb= new BookingBean(roomid, fromdate, todate, noofadults, noofchildren);
	int i=serv.booking(bb);
	
	if(i>0) {
		System.out.println("Your Booking for room "+ roomid + " for Hotel id "+hotelid +" is Successful" );
		System.out.println("Your Booking id is " +serv.getbookingid());
	}else
		System.out.println("An error occured while Booking");
}


//---------------------------BOOKING STATUS------------------------------------
public static void bookingStatus() throws HotelException {
		
	if(loggedin==false) {
		System.out.println("Please Login to continue...");
		i=login();
		}	
	if(loggedin==true) 
	{
		System.out.println("Enter your Booking id");
		String bookingId=scan.next();
		BookingBean bb=serv.bookingStatus(bookingId);
		if(bb!=null) {
		System.out.println(bb.toString());}
		else {
			System.out.println(" No bookings found for this id ");
		}
	}	
	}




}