package com.cg.JavaAssignmentLab2;

import java.util.Scanner;



public class NumberPostiveNegativeZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		int number=input.nextInt();
		if(number==0){
			System.out.println("Number is zero");
		}
		else if(number>0){
			System.out.println("Number is positive");
		}
		else{
			System.out.println("Number is negative");
		}
		input.close();
	}

}
