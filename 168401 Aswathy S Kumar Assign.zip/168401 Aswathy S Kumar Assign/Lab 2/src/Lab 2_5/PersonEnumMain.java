package com.cg.JavaAssignmentLab2;

public class PersonEnumMain {
	public static void main(String[] aa){
		PersonEnum p = new PersonEnum("Aswathy", "Ajith", Gender.F, 20, 85.55);
		System.out.print(p);
	}
}
