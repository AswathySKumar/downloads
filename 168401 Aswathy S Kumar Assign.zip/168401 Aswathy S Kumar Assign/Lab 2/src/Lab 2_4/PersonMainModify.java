package com.cg.JavaAssignmentLab2;

public class PersonMainModify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonModify pi = new PersonModify("Aswathy","Ajith",'F',"9643524512");
		pi.display();
		
	}

}
