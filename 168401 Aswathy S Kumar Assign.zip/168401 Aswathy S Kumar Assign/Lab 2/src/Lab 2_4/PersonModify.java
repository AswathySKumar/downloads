package com.cg.JavaAssignmentLab2;

public class PersonModify {
	private String fname,lname,mobileno;
	private char gender;
	
	public PersonModify() {}
	
	PersonModify(String fname,String lname,char gender,String mobileno){
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
		this.mobileno=mobileno;
	}
	
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}


	void display(){
		System.out.println("Person Deatils"+"\n-----------"+"\nFirst Name: "+fname+"\nLast Name: "+lname+"\nGender: "+gender+"\nMobile Number:"+mobileno);
	}
}
