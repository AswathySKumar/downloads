package com.capgemini.javaclasslib.stringoperations;

import java.util.Scanner;

public class TestStringOperations {

    public static void main(String[] args) {
    	
    	System.out.println("Enter : \n1. To Add String to itself. \n2. To Replace odd values of String with '#'."
    			+ " \n3. To Replace odd values of String with 'UpperCase'. \n4.To Remove Duplicate Values from String.");
    	
    	System.out.println("\nEnter number :");
    	Scanner sc = new Scanner(System.in);
    	int num = sc.nextInt();
    	
    	
    	switch(num){
    		
    	case 1:
    		
    		  System.out.println("Enter the Value of String to Add itself : \n");
    	      String str = sc.next();
    	      AddStringitself strConcat = new AddStringitself();
    	      strConcat.AddStr(str);
    	      break;
    		
    	case 2:
    		
    		System.out.println("Enter the Value of String for Replace Positon with '#' : \n");
    		String str1 = sc.next();
    		ReplacePos ReplacedStr = new ReplacePos();
          	ReplacedStr.replacePos(str1);
          	break;
    		
    	case 3:
    		
    		System.out.println("Enter the Value of String for Replace Positon with UpperCase : \n");
    		String str2 = sc.next();
    		ReplaceToUpper UpperCase = new ReplaceToUpper();
          	UpperCase.replaceToUpper(str2);
          	break;
          	
    	case 4:
    		
    		System.out.println("Enter the Value of String to Remove Duplicate Values : \n");
    		String string = sc.next();
    		DuplicateChar Duplicate = new DuplicateChar();
            Duplicate.removeDup(string);
            break;
    	}
    	sc.close();
    	
    }

}