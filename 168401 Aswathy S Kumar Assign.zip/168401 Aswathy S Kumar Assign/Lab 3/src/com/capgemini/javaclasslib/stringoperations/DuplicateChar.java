package com.capgemini.javaclasslib.stringoperations;

public class DuplicateChar {
	
	
    public void removeDup(String string){

    	String str2 = "";
        
         char[] chrArray = string.toCharArray();
         for (char value : chrArray) {
             
             if (str2.indexOf(value) == -1) {
                 str2 += value; 
             }
         }
         System.out.println("Entered String Without Duplicates:  " +str2);
         
    }

}