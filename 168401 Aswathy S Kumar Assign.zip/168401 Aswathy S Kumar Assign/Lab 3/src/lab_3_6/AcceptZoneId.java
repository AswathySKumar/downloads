package lab_3_6;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class AcceptZoneId {

    public void CalZoneId(){
        ZonedDateTime currentTime = ZonedDateTime.now();

        ZonedDateTime currentTimeInParis = currentTime.withZoneSameInstant(ZoneId.of("Europe/Paris"));
        ZonedDateTime currentTimeInNewYork = currentTime.withZoneSameInstant(ZoneId.of("America/New_York"));
        ZonedDateTime currentTimeInLondon = currentTime.withZoneSameInstant(ZoneId.of("Europe/London"));
        ZonedDateTime currentTimeInTokyo = currentTime.withZoneSameInstant(ZoneId.of("Asia/Tokyo"));
        
        System.out.println("Time in INDIA : "+ currentTime);
        System.out.println("Time in PARIS : "+ currentTimeInParis);
        System.out.println("Time in NEW_YORK : "+ currentTimeInNewYork);
        System.out.println("Time in LONDON : "+ currentTimeInLondon);
        System.out.println("Time in TOKYO : "+ currentTimeInTokyo);
    }
}