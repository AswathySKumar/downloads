package lab_7_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SortArrayList {

    public static void main(String[] args) {

        ArrayList<String> list=new ArrayList<String>();
        list.add("Pens");
        list.add("Perfume");
        list.add("Books");
        list.add("Bags");
        list.add("Clothes");
        System.out.println("List Before Sorting : \n");
        Iterator<String> itr = list.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        Collections.sort(list);
        System.out.println("\nList After Sorting : \n");
        Iterator<String> it = list.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
    }

}