package com.cg.test;

import org.junit.Test;

import com.cg.beans.Person;

import static org.junit.Assert.*;
public class PersonMethodsTest
{
	@Test
	public void testGetFullName()	{
		System.out.println("from TestPerson2");
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	}
	
	@Test
	public void testGetFirstName() {
		Person per = new Person("Robert","King");
		assertEquals("Robert",per.getFirstName());
	}
	
	@Test
	public void testGetLastName() {
		Person per = new Person("Robert","King");
		assertEquals("King",per.getLastName());
	}
	
	@Test (expected=IllegalArgumentException.class)
	public void testNullsInName()	{
		System.out.println("from TestPerson2 testing exceptions");
		Person per1 = new Person(null,null);
	}
	
		
}