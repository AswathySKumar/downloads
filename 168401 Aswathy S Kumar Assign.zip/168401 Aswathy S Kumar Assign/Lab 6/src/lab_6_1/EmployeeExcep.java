package lab_6_1;

public class EmployeeExcep {

     public String FirstName; 
     public String LastName;
     public char Gender;

    public String getFirstName(){
        return this.FirstName;
    }
    public void setFirstName(String firstName){
        this.FirstName = firstName;
    }
    
    public String getLastName(){
        return this.LastName;
    }
    public void setLastName(String lastName){
        this.LastName = lastName;
    }
    
    public char getGender(){
        return this.Gender;
    }
    public void setGender(char gender){
        this.Gender = gender;
    }
}