package com.cg.Lab10Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {
	public static void addEmployeeDetails(){
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Employee Name: ");
	String name=sc.next();
	System.out.println("Enter Employee Id: ");
	int id=sc.nextInt();
	System.out.println("Enter salary : ");
	int salary=sc.nextInt();
	System.out.println("Enter Desgination: ");
	String desg=sc.next();
	String sql="Insert into employeedb values(?,?,?,?)";
	Connection con=DatabaseConnection.getConnection();
	try{
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setString(1, name);
		ps.setInt(2, id);
		ps.setInt(3, salary);
		ps.setString(4, desg);
		int res=ps.executeUpdate();
		System.out.println("Details inserted......");
	}catch(SQLException e){
		e.printStackTrace();
	}
}
	public static void deleteData(){
	String sql="delete from employeedb where id=?";
	Connection con=DatabaseConnection.getConnection();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Employee Id: ");
	int id=sc.nextInt();
	try{
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setInt(1, id);
		int res=ps.executeUpdate();
		System.out.println(res+ "rows deleted......");
	}catch(SQLException e){
		e.printStackTrace();
	}
}
	   public static List<Employee> displayEmployeeDetails(){
		   List<Employee> elist = new ArrayList<Employee>();
		   String sql = "select * from employeedb";
		   Connection con = DatabaseConnection.getConnection();
		   try {
			   Statement st = con.createStatement();
			   ResultSet rst = st.executeQuery(sql);
			   while (rst.next()) {
				   Employee e = new Employee();
				   e.setName(rst.getString("name"));
				   e.setId(rst.getInt("id"));
				   e.setSalary(rst.getInt("salary"));
				   e.setDesg(rst.getString("desg"));
				   elist.add(e);
        }
    } catch (SQLException e) {
       e.printStackTrace();
    }
    return elist;
  }

	public static void main(String[] args) {
		EmployeeMain rst = new EmployeeMain();
        do{
            System.out.println("  Menu  ");
            System.out.println("1. Add Employee Details ");
            System.out.println("2. Display Employee Details");
            System.out.println("3. Delete Employee details");
            System.out.println("4. Exit");
            System.out.println("5. Enter Your Choice");
            Scanner sc=new Scanner(System.in);
            int choice = sc.nextInt();
            switch(choice){
            case 1:
                System.out.println("Enter Employee Details");
                addEmployeeDetails();
                break;
            case 2:
            	List<Employee> rlist = rst.displayEmployeeDetails();
				if(rlist.size()==0){
				    System.out.println("No Details Available");
				}else {
				    rlist.stream().forEach(System.out::println);
				}
            	break;
            case 3:
            	deleteData();
            	break;
            case 4: System.out.println("Thank you");
            System.exit(0);
            default:
                System.out.println("Invalid Choice....Try Again");
                }
		
        } while(true);
	}
}


