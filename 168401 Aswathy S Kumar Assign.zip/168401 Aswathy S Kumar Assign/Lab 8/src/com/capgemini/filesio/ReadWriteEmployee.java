package com.capgemini.filesio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

@SuppressWarnings("serial")
public class ReadWriteEmployee implements Serializable {
	
	private static int id;
	private static String name;
	private static double salary;
	private static String designation;
	private static String insuranceScheme;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		ReadWriteEmployee.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		ReadWriteEmployee.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		ReadWriteEmployee.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		ReadWriteEmployee.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		ReadWriteEmployee.insuranceScheme = insuranceScheme;
	}

	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ReadWriteEmployee emp=new ReadWriteEmployee();
		emp.setId(101);
		emp.setName("teja");
		emp.setSalary(10000);
		emp.setDesignation("Manager");
		emp.setInsuranceScheme("Scheme A");
		FileOutputStream fos=new FileOutputStream("employee");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(emp);
		System.out.println("\nFile Has been Written Succesfully \n");
		oos.close();
		fos.close();
		
		//Displaying Employee Details By using FileInputStream
		System.out.println("\nEmployee Details :");
		System.out.println("\n-----------------------------------------------------\n");
		FileInputStream fis=new FileInputStream("employee");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Object obj=ois.readObject();
		emp=(ReadWriteEmployee) obj;
		System.out.println("Employee ID : "+emp.getId());
		System.out.println("Employee Name : "+emp.getName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee Designation " +emp.getDesignation());
		System.out.println("Employee Insurance Scheme : "+emp.getInsuranceScheme());
		System.out.println("\n-----------------------------------------------------\n");
		System.out.println("Read Operation on file has been successful");
		
		
		ois.close();

	}

}