package com.ams.dtobean;

import java.util.Scanner;

public class Dummy {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int type=0;
	System.out.println("enter username");
	String un=scan.next();
	System.out.println("enter password");
	String pass= scan.next();
	do {
	System.out.println("select usertype \n"+"1.Manager \n"+"2. Admin");
	type=scan.nextInt();
	if(type<1||type>2)
		System.out.println("Enter valid user type");
	}while(type<1||type>2);
	switch(type) {
	
	}
	
	
}
}
