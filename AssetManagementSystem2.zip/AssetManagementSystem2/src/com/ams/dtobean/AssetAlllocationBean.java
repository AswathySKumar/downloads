package com.ams.dtobean;

public class AssetAlllocationBean {
	
	private int allocationId;
	private int assetId;
	private int empNo;
	private String allocationDAte;
	private String releaseDate;
	
	
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getAllocationDAte() {
		return allocationDAte;
	}
	public void setAllocationDAte(String allocationDAte) {
		this.allocationDAte = allocationDAte;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	

}
