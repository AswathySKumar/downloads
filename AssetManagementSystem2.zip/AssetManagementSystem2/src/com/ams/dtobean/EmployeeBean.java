package com.ams.dtobean;

public class EmployeeBean {
private int empNo;
private String empName;
private String job;
private int mgrNo;
private String raiseDate;
private int deptId;
public EmployeeBean() {
	super();
	// TODO Auto-generated constructor stub
}
public int getEmpNo() {
	return empNo;
}
public void setEmpNo(int empNo) {
	this.empNo = empNo;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getJob() {
	return job;
}
public void setJob(String job) {
	this.job = job;
}
public int getMgrNo() {
	return mgrNo;
}
public void setMgrNo(int mgrNo) {
	this.mgrNo = mgrNo;
}
public String getRaiseDate() {
	return raiseDate;
}
public void setRaiseDate(String raiseDate) {
	this.raiseDate = raiseDate;
}
public int getDeptId() {
	return deptId;
}
public void setDeptId(int deptId) {
	this.deptId = deptId;
}










}
