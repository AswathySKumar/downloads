package com.ams.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ams.dao.IQueryMapper;
import com.ams.dtobean.AssetAlllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;
import com.ams.service.AssetService;
import com.ams.service.IAssetService;
import com.ams.util.DbUtil;


public class AssetClient {
	static Scanner scan=null;
	static IAssetService serv=null;
	static AssetBean bean=null;
	static Logger logg=Logger.getRootLogger();
	public static void main(String[] args) throws AssetException, SQLException {
		PropertyConfigurator.configure("resource/log4j.properties");
		System.out.println("===Asset management system===");
		System.out.println("--------------------------------");
		Scanner scan=new Scanner(System.in);
		int type=0;
		do {
			System.out.println("select usertype \n"+"1.Manager \n"+"2. Admin");
			type=scan.nextInt();
			if(type<1||type>2)
				System.out.println("Enter valid user type");
			}while(type<1||type>2);
			
		
		serv = new AssetService();
		
		boolean valid=serv.validateuserType();	
		
		int assetid;
		String assetName;
		String assetDesc;
		int quantity;
		String status;
		  switch(type) {
		  case 1: System.out.println("Enter the choice \n"+"1. Raise a request \n"+"2. View status of Raised requests");
		          int choice1=scan.nextInt();
		          switch(choice1) {
		          case 1: System.out.println("Enter the details");
		                  
		          
		          
		          break;
		          
		          
		          
		          
		          
		          
		          
		          
		          }break;
		        
		  case 2:
		         System.out.println("Enter the choice\n 1.Insert\n 2.Update");
		         int choice=scan.nextInt();
		         int staus=0;
		         switch(choice)
		         {
		          case 1:
		        	     System.out.println("Insert details");
			             System.out.println("Enter the asset name ");
			             assetName=scan.next();
			             System.out.println("Enter the assetDesc");
			             assetDesc=scan.next();
			             System.out.println("Enter the quantity");
			             quantity=scan.nextInt();
			             System.out.println("Enter the status");
			             status=scan.next();
			             bean=new AssetBean(assetName,assetDesc,quantity,status);
		
		                 int add=insertAsset(bean);
		                 if(add>0)
		                 {
			                System.out.println("inserted");
		                 }
		                else
		                 {
			                System.out.println("not inserted");
		                 } 
		         
			           break;
		         case 2:int status1=0;
		         Connection con=DbUtil.getDbConnection();
		        	    System.out.println("Update asset");
		                
			            System.out.println("Enter Asset Id");
			            int id = scan.nextInt();
			            System.out.println("Enter name to be updated");
			            String name=scan.next();
			           
			           // String q="UPDATE asset SET assetName=? WHERE assetId=?";
			            try{
			    	    status1=updateAsset(id,name);
			    	  //  System.out.println(status1);
			    	    if(status1>0){
					    	   System.out.println(status1+"data is updated");
					            }
					           else{
					    	    System.out.println("data is not updated");
					           }
			    	    //System.out.println(rb);
			            }
			           catch(AssetException re){
		   			   System.out.println(re.getMessage());			    	   
			            }
			           
			           break;
		         case 3:System.exit(0);
			           default:System.out.println("Invalid choice!!");
			           break;
		
		          }
		  }
        
		}
	public static int raiseRequest(AssetAlllocationBean allocBean) throws AssetException {
		
		serv=new AssetService();
		return serv.raiseRequest(allocBean);
		
		}
		public static AssetBean viewStatusOfRaisedRequest() {
			
			return null;
		}
	public static int insertAsset(AssetBean bean2) {
		serv= new AssetService();
		return serv.insertAsset(bean2);
	}
	public static int updateAsset(int id,String name) throws AssetException {
		serv= new AssetService();
		
		return serv.updateAsset(id,name);
	}
	
}