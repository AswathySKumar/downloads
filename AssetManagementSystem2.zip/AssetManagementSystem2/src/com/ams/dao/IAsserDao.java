package com.ams.dao;

import java.util.List;

import com.ams.dtobean.AssetAlllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;

public interface IAsserDao {
	public abstract AssetBean validateUserType(String un) throws AssetException;

	public abstract int insertAsset(AssetBean bean2);

	public abstract int updateAsset(int id,String name) throws AssetException;

	public abstract int raiseRequest(AssetAlllocationBean allocBean) throws AssetException;
	
	public abstract int validateAssetId(int assetId) throws AssetException;

}
