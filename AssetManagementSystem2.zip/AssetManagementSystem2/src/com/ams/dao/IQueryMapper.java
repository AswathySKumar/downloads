package com.ams.dao;

public interface IQueryMapper {
	public static final String SELECT_USERTYPE_QRY="SELECT username,userpassword FROM user_master WHERE username=?";
	public static final String INSERT_QUERY="insert into asset values(asset_seq.NEXTVAL,?,?,?,?)";
	public static final String ASSET_UPDATE_NAME="UPDATE asset SET ASSETNAME=? WHERE assetId=?";
	public static final String ASSET_ALLOCATION_INSERT_QUERY="insert into Asset_Allocation values(allocationid_seq.NEXTVAL,?,?,SYSDATE,?)";
    public static final String VALIDATE_ASSET_ID="SELECT AssetId FROM Asset WHERE AssetId =?";

}
