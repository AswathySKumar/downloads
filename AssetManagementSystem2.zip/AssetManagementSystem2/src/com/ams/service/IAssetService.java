package com.ams.service;

import java.util.List;

import com.ams.dtobean.AssetAlllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;

public interface IAssetService {

	public abstract boolean validateuserType() throws AssetException;

	public abstract int insertAsset(AssetBean bean2);

	public abstract int updateAsset(int id,String name) throws AssetException;

	public abstract int raiseRequest(AssetAlllocationBean allocBean) throws AssetException;
 
	public abstract int validateAssetId() throws AssetException;
}
