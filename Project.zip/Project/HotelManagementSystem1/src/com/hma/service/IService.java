package com.hma.service;

public interface IService {

}
