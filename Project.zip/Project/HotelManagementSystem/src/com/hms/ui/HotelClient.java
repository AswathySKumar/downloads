package com.hms.ui;

import java.util.Scanner;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

public class HotelClient {
	private static String user_id;
	private static String password;
	static Scanner scan=null;
	static IHotelService serv=null;
	static HotelBean hb=null;
	static UserBean ub=null;
//	static RoomDetailsBean rdb=null;
	static BookingBean bb=null;
	
public static void main(String[] args) throws HotelException {
	scan= new Scanner(System.in);
	System.out.println("Welcome to HOLIDAYINN");
	System.out.println("1.Login or Register");
	System.out.println("2.Book room");
	System.out.println("3.Show booking status");
	int option=scan.nextInt();
	switch(option){
	case 1:
		System.out.println("are you already registered");
		String reg=scan.next();
		//reg.toLowerCase();
		if((reg.toLowerCase().equals("yes"))){
			login();
	
			break;
		
		
		}
		else
		{
			register();
		}
		
		
		
	}
	
}
private static void register () throws HotelException{

	System.out.println("please enter your id ");
	user_id=scan.next();
	System.out.println("please enter your password ");
	 password=scan.next();

		System.out.println("please enter your role");
		String role = scan.next();
		System.out.println("please enter your username");
		 String username = scan.next();

			System.out.println("please enter your mobilenumber ");
			String mblnum = scan.next();
			System.out.println("please enter your phone ");
			 String ph = scan.next();

				System.out.println("please enter your address ");
				String add = scan.next();
				System.out.println("please enter your email ");
				 String email = scan.next();
			
				ub=new UserBean(email, email, role, username, mblnum, ph, add, email);
				 
			 try{
				 serv=new HotelServiceImpl();
				 IHotelService.register();
			 }
		 

	
}
private static void login() {
	
	System.out.println("please enter your id ");
	user_id=scan.next();
	System.out.println("please enter your password ");
	 password=scan.next();
	 
	 serv= new HotelServiceImpl();
	 boolean status=serv.login(user_id,password);
	if(status==true){
	
		System.out.println(" 1. Check room Availability\n 2. Check Booking Status ");	
		int option1=scan.nextInt();
		switch (option1) {
		case 1: 
			serv.availrooms();
			
			break;
			
		case 2: 
			serv.bookingstatus();
			
			break;

		default:
			break;
		}
		
		
	}
	else{
		System.out.println(" Crediantials not found, Please enter correct details or register again ");
	}
}
}
