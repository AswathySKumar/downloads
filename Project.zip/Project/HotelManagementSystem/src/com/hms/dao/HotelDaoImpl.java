package com.hms.dao;

public class HotelDaoImpl {

}
