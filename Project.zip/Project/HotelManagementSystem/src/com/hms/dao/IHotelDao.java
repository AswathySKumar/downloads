package com.hms.dao;

public interface IHotelDao {

}
