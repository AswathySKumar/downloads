package com.hms.service;

public class HotelServiceImpl implements IHotelService{

	



}
