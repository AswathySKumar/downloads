package com.hms.service;

public interface IHotelService {

	boolean login(String user_id, String password);

}
