package com.ab.bean;

public class AirBean {
private int flightId;
private String flightName;
private String arrivalPoint;
private String depPoint;
private String flightDate;
private int availableSeats;
private int bookingId;
public int getFlightId() {
	return flightId;
}
public void setFlightId(int flightId) {
	this.flightId = flightId;
}
public String getFlightName() {
	return flightName;
}
public void setFlightName(String flightName) {
	this.flightName = flightName;
}
public String getArrivalPoint() {
	return arrivalPoint;
}
public void setArrivalPoint(String arrivalPoint) {
	this.arrivalPoint = arrivalPoint;
}
public String getDepPoint() {
	return depPoint;
}
public void setDepPoint(String depPoint) {
	this.depPoint = depPoint;
}
public String getFlightDate() {
	return flightDate;
}
public void setFlightDate(String flightDate) {
	this.flightDate = flightDate;
}
public int getAvailableSeats() {
	return availableSeats;
}
public void setAvailableSeats(int availableSeats) {
	this.availableSeats = availableSeats;
}

public int getBookingId() {
	return bookingId;
}
public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}
public AirBean() {
	super();
	// TODO Auto-generated constructor stub
}
public AirBean(int flightId, String flightName, String arrivalPoint, String depPoint, String flightDate,
		int availableSeats) {
	super();
	this.flightId = flightId;
	this.flightName = flightName;
	this.arrivalPoint = arrivalPoint;
	this.depPoint = depPoint;
	this.flightDate = flightDate;
	this.availableSeats = availableSeats;
}
public AirBean(int flightId , String flightName, String arrivalPoint , String depPoint, int availableSeats) {
	this.flightId = flightId;
	this.flightName = flightName;
	this.arrivalPoint = arrivalPoint;
	this.depPoint = depPoint;
	this.availableSeats = availableSeats;
}
@Override
public String toString() {
	return "AirBean [flightId=" + flightId + ", flightName=" + flightName + ", arrivalPoint=" + arrivalPoint
			+ ", depPoint=" + depPoint + ", availableSeats=" + availableSeats + "]";
}


}
