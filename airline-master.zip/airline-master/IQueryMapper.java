package com.ab.dao;

public interface IQueryMapper {
	public static String insert_query="INSERT INTO flight_details1 VALUES(?,?,?,?,SYSDATE,?,jdbc_seq4.nextval)";
	public static String retrive_query="SELECT * from flight_details1 where flight_id=?";
	public static String update_query="update flight_details1 set available_seats=? where flight_id=?";
	public static String get_booking="SELECT booking_id from flight_details1 where flight_id=?";
	public static String flight_check="SELECT flight_id from flight_details1 where flight_id=?";
	
}
