package com.ab.util;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {
private static	Connection connection=null;
	
	public static Connection getConnection() throws Exception
	{
	
		Properties p=new Properties();
		
		
		FileInputStream fIS=new FileInputStream("C:\\Users\\SIRISH\\eclipse-workspace\\doctorappointment\\src\\resources\\dbconfig.properties");
			
			p.load(fIS);
			String driver=p.getProperty("driver");
			String url=p.getProperty("url");
			String username=p.getProperty("username");
			String password=p.getProperty("password");
			
	
	try
	{
		Class.forName(driver);
		connection=DriverManager.getConnection(url,username,password);
		
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	catch(SQLException s)
	{
		s.printStackTrace();
	}
	
	return connection;
	}
}
