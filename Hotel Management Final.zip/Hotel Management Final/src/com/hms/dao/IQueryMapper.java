package com.hms.dao;

public interface IQueryMapper {

	public static final String Login_QRY="select * from users where user_id=? and password=?";
	
	public static final String Insert_QRY="insert into users values(?,?,?,?,?,?,?,?)";
	
	public static final String BookingStatus_QRY="select * from BookingDetails where BOOKING_ID=?";
	
	public static final String Allhotel_QRY="select * from hotel";
	
	public static final String hotelroom_QRY=" select * from roomdetails where hotel_id=?";
	
	public static final String Booking_QRY="insert into bookingdetails values(hotelsequence.NEXTVAL,?,?,?,?,?,?,?,?)";
	
	public static final String rate_QRY=" select PER_NIGHT_RATE from roomdetails where ROOM_ID=? ";
	
	public static final String getBookingid_QRY=" select booking_id from bookingdetails where user_id=?";
	
	public static final String Useridcheck_QRY="select * from users where user_id=?";
	
	public static final String rromid_QRY="select * from roomdetails where room_id=?";
	
	public static final String hotelid_QRY="select * from hotel where hotel_id=?";
	
/*	public static final String getAllBookings_QRY="select * from bookingdetails where user_id=?";*/
	
	
	public static final String GET_ALL_HOTELS= "Select * from hotel";
	public static final String GET_ALL_ROOMS="Select * from roomdetails where hotel_id=?";
	public static final String GET_BY_ROOMID="Select * from roomdetails where room_id=?";
	public static final String ADD_HOTELS = "insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String FIND_HOTEL ="select * from hotel where hotel_id=?";
	public static final String UPDATE_CITY ="UPDATE hotel SET city=? where hotel_id=?";
	public static final String UPDATE_HOTEL_NAME = "UPDATE hotel SET hotel_name=? where hotel_id=?";
	public static final String UPDATE_HOTEL_ADDRESS = "UPDATE hotel SET address=? where hotel_id=?";
	public static final String UPDATE_HOTEL_DESC = "UPDATE hotel SET description=? where hotel_id=?";
	public static final String UPDATE_HOTEL_RPN ="UPDATE hotel SET  AVG_RATE_PERNIGHT=? where hotel_id=?";
	public static final String UPDATE_HOTEL_PN1 ="UPDATE hotel SET  PHONE_NO1=? where hotel_id=?";
	public static final String UPDATE_HOTEL_PN2 = "UPDATE hotel SET  PHONE_NO2=? where hotel_id=?";
	public static final String UPDATE_HOTEL_RATING = "UPDATE hotel SET  rating=? where hotel_id=?";
   	public static final String hotel_detail ="select * from bookingdetails where hotel_id=?";
	public static final String get_by_date = "select * from  bookingdetails where BOOKED_FROM=?";
	public static final String ADD_ROOMS = "insert into roomdetails values(?,?,?,?,?,?)";
	public static final String DEL_ROOMS = "delete from roomdetails where room_id=?";
	public static final String UPDATE_ROOM_NUM = "UPDATE roomdetails SET room_no=? where room_id=?";
	 public static final String UPDATE_HOTEL_ROOMYPE = "UPDATE roomdetails SET room_type=? where room_id=?";
	public static final String UPDATE_ROOM_PRICE = "UPDATE roomdetails SET per_night_rate=? where room_id=?";
	public static final String UPDATE_ROOM_AVAILABILITY = "UPDATE roomdetails SET availability=? where room_id=?";
	
	
	
}
