package com.hms.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.text.ParseException;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;
import com.hms.util.DbUtil;

public class HotelDaoImpl implements IHotelDao {
	
	Logger log=Logger.getRootLogger();
	Connection conn=null;
	static int noof_days;
	static String userid, hotel_id;
	static int status;
//====================================LOGIN==============================================
	@Override
	public boolean login(String user_id, String password) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		String id=null, pass=null;
		conn=DbUtil.getDbConnection();
		try {
				String s=IQueryMapper.Login_QRY;	
				PreparedStatement pst=conn.prepareStatement(s);
				pst.setString(1,user_id);
				pst.setString(2,password);
				ResultSet rs=pst.executeQuery();
				while(rs.next()) {
						id=rs.getString("user_id");
						pass=rs.getString("password");
						break;
				}
				if((id!=null)&&(pass!=null)) {
					log.info("credentials found.Authorised user");
					return true;
				}
				else 
					return false;
		} catch (SQLException e) {
			log.error("invalid user");
			throw new HotelException("couldn't retrieve data from db  "+e.getMessage());
		}
	}

//==================================== REGISTER =====================================================	
	
	@Override
	public int register(UserBean ub) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int status=0;
		
		try {
			String s1=IQueryMapper.Insert_QRY;	
			PreparedStatement pst=conn.prepareStatement(s1);
			pst.setString(1, ub.getUser_id());
			pst.setString(2, ub.getPassword());
			pst.setString(3, ub.getRole());
			pst.setString(4, ub.getUser_name());
			pst.setString(5, ub.getMobile_no());
			pst.setString(6, ub.getPhone());
			pst.setString(7, ub.getAddress());
			pst.setString(8, ub.getEmail());
			status=pst.executeUpdate();
			
		} catch (Exception e) {
			
				System.out.println(" Error Occured ");
		}
		
		return status;
	}

//===================================BOOKING STATUS==========================================
	
	@Override
	public BookingBean bookingStatus(String bookingId) {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		ResultSet rs=null;
		BookingBean bb=null;
		
		try {
			
			String s1=IQueryMapper.BookingStatus_QRY;	
			PreparedStatement pst=conn.prepareStatement(s1);
			pst.setString(1, bookingId);
			rs=pst.executeQuery();	
			while(rs.next()){
				bb= new BookingBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5),rs.getInt(6), rs.getInt(7), rs.getInt(8));	
				log.info("retrieved booking status");
			}
		}catch (Exception e) {
			System.out.println("Error occured while processing "+ e.getMessage());
			log.error("Error occured while processing bookingstatus");
		}
	
		return bb;
	}

//==================================GET ALL HOTELS================================================================	
	@Override
	public List<HotelBean> Allhotel() {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		List<HotelBean> hotelList=null;
		HotelBean hb=null;
		try {
		String s=IQueryMapper.Allhotel_QRY;
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(s);
		hotelList= new ArrayList<>();
		
		while(rs.next()) {
		
			hb=new HotelBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), 
					rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11));
			hotelList.add(hb);
			log.info("hotel details are retrieved");
		}
		
		}catch (Exception e) {
			System.out.println("Error occured " + e.getMessage());
			log.error("Error occured during hoteldetails retrieval");
		}
	
		return hotelList;
	}

//===============================GET AVAILABLE ROOMS========================================================
	@Override
	public List<RoomDetailsBean> availrooms(String hotelid) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		RoomDetailsBean rdb= null;
		List<RoomDetailsBean> rdbList=null;
		try {
			
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.hotelroom_QRY);
			pst.setString(1, hotelid);
			ResultSet rs=pst.executeQuery();
			rdbList= new ArrayList<>();
			while(rs.next()) {
				rdb= new RoomDetailsBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
				 rdbList.add(rdb);
				 log.info("room details retrieved");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			log.error("error occured during Room details retrieval");
			
		}
		
		return  rdbList;
	}

	
//===================================VARIBLE INITIALIZATION=========================================================
	
	

	@Override
	public void noofdays(String user_id,int noofdays,String hotelid) throws HotelException{
		PropertyConfigurator.configure("resources/log4j.properties");
			userid=user_id;
			noof_days=noofdays;	
			hotel_id=hotelid;
	}
	
//===================================USER ROOM BOOKING=========================================================
	@Override
	public int booking(BookingBean bb) {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int status=0; int room_amount=0;
	
		try {
			String roomid=bb.getRoom_id();
			PreparedStatement pst1=conn.prepareStatement(IQueryMapper.rate_QRY);
			pst1.setString(1, roomid);
			ResultSet rs=pst1.executeQuery();
			while(rs.next()) {
				room_amount=rs.getInt("PER_NIGHT_RATE"); break;
			}
		
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Booking_QRY);
			pst.setString(1,bb.getRoom_id());
			pst.setString(2,userid);		
			pst.setString(3, bb.getBooked_from());		
			pst.setString(4,  bb.getBoooked_to());			
			pst.setInt(5, bb.getNo_of_adults());			
			pst.setInt(6, bb.getNo_of_children());
			
			int totalamount= room_amount*noof_days;		
			pst.setInt(7, totalamount);	
			pst.setString(8,hotel_id);
			status=pst.executeUpdate();
			log.info("userdetails added successfully");
			
						
		} catch (Exception e) {
			System.out.println(e.getMessage());
			log.error("booking failed");
		}
		return status;
	}
	
//===================================GET BOOKING ID=========================================================

	@Override
	public int getbookingid() throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		int bookingid=0;
		
		
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.getBookingid_QRY);
			pst.setString(1, userid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
			bookingid=rs.getInt("BOOKING_ID"); 
			break;
			
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return bookingid;
	
	}
	
	
//============================FOR CHECKING IF USERID ALREADY EXIST OR NOT=============================================	

	@Override
	public boolean useridcheck(String user_id) throws HotelException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getDbConnection();
		boolean useridfound=false;
		ResultSet rs=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Useridcheck_QRY);
			pst.setString(1, user_id);
			rs=pst.executeQuery();
			
			while(rs.next()) {
				useridfound=true;
				log.info("user id already exists");
				 break;
			}
					
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return useridfound;
	
	}

	@Override
	public boolean getroomid(String roomid) {
		
		conn=DbUtil.getDbConnection();
		ResultSet rs=null;
		boolean roomidfound=false;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.rromid_QRY);
			pst.setString(1, roomid);
			rs=pst.executeQuery();
			
			while(rs.next()) {
				roomidfound=true;
				log.info("");
				 break;
			}
	
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return roomidfound;
	}

	@Override
	public boolean gethotelid(String hotelid) {
		conn=DbUtil.getDbConnection();
		ResultSet rs=null;
		boolean hotelidfound=false;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.hotelid_QRY);
			pst.setString(1, hotelid);
			rs=pst.executeQuery();
			
			while(rs.next()) {
				hotelidfound=true;
				log.info("");
				 break;
			}
	
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return hotelidfound;
	}

	/*@Override
	public List<BookingBean> getAllBookings(String user_id) {
		conn=DbUtil.getDbConnection();
		ResultSet rs=null;
		List<BookingBean> bookinglist=null;
		BookingBean bb=null;
			try {

			PreparedStatement pst=conn.prepareStatement(IQueryMapper.getAllBookings_QRY);
			pst.setString(1, user_id);
			rs=pst.executeQuery();
			bookinglist= new ArrayList<>();
			while(rs.next()) {
				bb= new BookingBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5),rs.getInt(6), rs.getInt(7), rs.getInt(8));
				bookinglist.add(bb);
				 log.info("room details retrieved");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			log.error("error occured during Room details retrieval");
			
		}
		
		return bookinglist;

	}*/
	
	
	//++++++++++++++++++===================================*****************************************************
	
	
	
	@Override
	public List<HotelBean> getAllHotels() throws HotelException {
		conn = DbUtil.getDbConnection();
		List<HotelBean> hList = null;
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(IQueryMapper.GET_ALL_HOTELS);
			hList = new ArrayList();
			HotelBean hbean=null;
			while(rs.next()) {
				hbean=new HotelBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
					rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11));
				hList.add(hbean);
		} }
			catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error occured");
		}
		
		return hList;
	}
	@Override
	public List<RoomDetailsBean> getAllRooms(String hid) {
		conn = DbUtil.getDbConnection();
		List<RoomDetailsBean> rList = null;
		rList = new ArrayList();
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(IQueryMapper.GET_ALL_ROOMS);
			pst.setString(1, hid);
			ResultSet rs = pst.executeQuery();
			
			
			RoomDetailsBean rbean = null;
			while(rs.next()) {
				rbean = new RoomDetailsBean(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
				rList.add(rbean);
				
		}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rList;
		
	
		
		

	}
	@Override
	public int addHotel(HotelBean hBean) {
		conn = DbUtil.getDbConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.ADD_HOTELS);
			pst.setString(1, hBean.getHotel_id());
			pst.setString(2, hBean.getCity());
			pst.setString(3, hBean.getHotel_name());
			pst.setString(4, hBean.getAddress());
			pst.setString(5, hBean.getDescription());
			pst.setString(6, hBean.getAvg_rate_per_night());
			pst.setString(7, hBean.getPhone_no1());
			pst.setString(8, hBean.getPhone_no2());
			pst.setString(9, hBean.getRating());
			pst.setString(10, hBean.getEmail());
			pst.setString(11, hBean.getFax());
			status=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	@Override
	public HotelBean getHotelById(String htid) {
		conn = DbUtil.getDbConnection();
		HotelBean hbean=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(IQueryMapper.FIND_HOTEL);
			pst.setString(1, htid);
			
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				hbean=new HotelBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
							rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return hbean;
	}
	@Override
	public int updateCity(String city1, String htid) {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(IQueryMapper.UPDATE_CITY);
			pst.setString(1, city1);
			pst.setString(2, htid);
			//HotelBean hbean=null;
			status = pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
		
	}
	@Override
	public List<BookingBean> getHotelDetails(String hotelId)  {
		conn = DbUtil.getDbConnection();
		BookingBean Bbean=null;
		List<BookingBean> bList1 = null;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.hotel_detail);
			pst.setString(1,hotelId);
			bList1= new ArrayList<>();
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				System.out.println("hbd");
				Bbean = new BookingBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),
						rs.getInt(7),rs.getDouble(8),rs.getString(9));
				bList1.add(Bbean);
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return bList1;
	}
	@Override
	public List<BookingBean> getDetailsByDate(String bdate)  {
		conn = DbUtil.getDbConnection();
		//SimpleDateFormat sp = null;
		//System.out.println(bdate);
		//SimpleDateFormat formatter2=new SimpleDateFormat("dd-MM-yyyy");  
		//Date date = formatter2.parse(bdate);
		//java.sql.Date datesq = new java.sql.Date(date.getTime());
		//System.out.println("DAte Sq is "+datesq);
		List<BookingBean> bList = null;
		try {
			
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.get_by_date);
			pst.setString(1, bdate);
			ResultSet rs = pst.executeQuery();
			bList = new ArrayList();
			BookingBean bbean=null;
			while(rs.next()) {
				bbean=new BookingBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),
						rs.getInt(7),rs.getDouble(8),rs.getString(9));
				bList.add(bbean);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return bList;
	}
	@Override
	public int raddadetails(RoomDetailsBean rbean) {
		conn = DbUtil.getDbConnection();
		try {
			PreparedStatement pst1 = conn.prepareStatement(IQueryMapper.ADD_ROOMS);
			pst1.setString(1,rbean.getHotel_id());
			pst1.setString(2,rbean.getRoom_id());
			pst1.setString(3,rbean.getRoom_no());
			pst1.setString(4,rbean.getRoom_type());
			pst1.setInt(5,rbean.getPer_night_rate());
			pst1.setString(6,rbean.getAvailability());
			status=pst1.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public int deleteroom(String rid1) {
		conn = DbUtil.getDbConnection();
		try {
			PreparedStatement pst2 = conn.prepareStatement(IQueryMapper.DEL_ROOMS);
			pst2.setString(1,rid1);
			status=pst2.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public int updateRoomNumber(String rnum, String rid2){
		conn = DbUtil.getDbConnection();
		PreparedStatement pst;

		try {
			pst = conn.prepareStatement(IQueryMapper.UPDATE_ROOM_NUM);
			pst.setString(1, rnum);
			pst.setString(2, rid2);
			HotelBean hbean5=null;
			status = pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		if (status>0) {
			
		}
		
		return status;
		
	}
	@Override
	public int updateName(String hname, String htid) {
		conn = DbUtil.getDbConnection();
		int result2=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_NAME);
			pst.setString(1,hname);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result2= pst.executeUpdate();
			if (result2>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result2;
	}
	@Override
	public int updateAddress(String haddress, String htid) {
		conn = DbUtil.getDbConnection();
		int result3=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_ADDRESS);
			pst.setString(1,haddress);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result3= pst.executeUpdate();
			if (result3>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result3;
	}
	@Override
	public int updateDesc(String hdesc, String htid) {
		conn = DbUtil.getDbConnection();
		int result4=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_DESC);
			pst.setString(1,hdesc);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result4= pst.executeUpdate();
			if (result4>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result4;
	}
	@Override
	public int updateRpn(String hrpn, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_RPN);
			pst.setString(1,hrpn);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;

	}
	@Override
	public int updatepn1(String hpn1, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_PN1);
			pst.setString(1,hpn1);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public int updateepn2(String hpn2, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_PN2);
			pst.setString(1,hpn2);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public int updateRating(String rating, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_RATING);
			pst.setString(1,rating);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public int updateRoomType(String rtype1, String rid2) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_ROOMYPE);
			pst.setString(1,rtype1);
			pst.setString(2,rid2);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public int updateRoomPrice(int ppn, String rid2) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_ROOM_PRICE);
			pst.setInt(1,ppn);
			pst.setString(2,rid2);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public int updateRoomAvailability(String avl, String rid2) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_ROOM_AVAILABILITY);
			pst.setString(1,avl);
			pst.setString(2,rid2);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
	@Override
	public List<RoomDetailsBean> getRoomById(String rid2) {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst;
		List<RoomDetailsBean> rList = null;
		rList = new ArrayList();
		try {
			pst = conn.prepareStatement(IQueryMapper.GET_BY_ROOMID);
			pst.setString(1, rid2);
			ResultSet rs = pst.executeQuery();
			
			
			RoomDetailsBean rbean = null;
			while(rs.next()) {
				rbean = new RoomDetailsBean(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
				rList.add(rbean);
				
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return rList;
	}
	
	
	
	
	
	
	
	
	//*****************************************************************************************************************
	
	
	

}
