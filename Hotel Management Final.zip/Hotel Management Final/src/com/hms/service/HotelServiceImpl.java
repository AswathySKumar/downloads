package com.hms.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;

import com.hms.dao.HotelDaoImpl;
import com.hms.dao.IHotelDao;
import com.hms.exception.HotelException;

public class HotelServiceImpl implements IHotelService{
	IHotelDao hdao=new HotelDaoImpl();;

	@Override
	public boolean login(String user_id, String password) throws HotelException {
	boolean status=hdao.login(user_id, password);
		return status;
	}

	

	@Override
	public BookingBean bookingStatus(String bookingId) throws HotelException {
		
		return hdao.bookingStatus(bookingId);
	}

	@Override
	public int register(UserBean ub) throws HotelException{
		int status=hdao.register(ub);
		return status;
	}

	@Override
	public List<HotelBean> AllHotel() {
	
		return hdao.Allhotel();
	}




	@Override
	public List<RoomDetailsBean> availrooms(String hotelid) throws HotelException {
		
		return hdao.availrooms(hotelid);
	}

/*	@Override
	public List<BookingBean> getAllBookings(String user_id) {
		
		return hdao.getAllBookings(user_id);
	}
	  */
	
	

	@Override
	public int booking(BookingBean bb) {
		int i=hdao.booking(bb);
		return i;
	}


	@Override
	public void noofdays(String user_id,int noofdays,String hotelid) throws HotelException {
		hdao.noofdays(user_id,noofdays,hotelid);
		
	}



	@Override
	public int getbookingid() throws  HotelException {
		int bookingid=hdao.getbookingid();
		return bookingid;
	}



	@Override
	public boolean useridcheck(String user_id) throws HotelException {
		boolean registerduserid=hdao.useridcheck(user_id);
		return registerduserid;
	}

	
	@Override
	public boolean getroomid(String roomid) {
		boolean roomidfound=hdao.getroomid(roomid);
		return roomidfound;
		
	}
	
	
	@Override
	public boolean hotelidcheck(String hotelid) {
		boolean hotelidfound=hdao.gethotelid(hotelid);
		return hotelidfound;
	}

	
	@Override

	public boolean validateid(String user_id) {

	Pattern pid= Pattern.compile("[0-9]{1,4}");

	Matcher mid=pid.matcher(user_id);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("only 4 numbers are allowed ");

	return false;

	}

	}

	@Override

	public boolean validatepassword(String password) {

	Pattern pass= Pattern.compile("[A-Za-z0-9@#&.]{4,7}");

	Matcher mid=pass.matcher(password);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("minimum 4 maximum 7 ");

	return false;

	}

	}


	@Override

	public boolean validaterole(String role) {

	Pattern rol= Pattern.compile("[A-Z][a-z]{1,20}");

	Matcher mid=rol.matcher(role);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum characters should be 10 ");

	return false;

	}

	}


	@Override

	public boolean validateusername(String username) {

	Pattern un= Pattern.compile("[A-Z][a-z]{3,20}");

	Matcher mid=un.matcher(username);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum allowed characters are 20 ");

	return false;

	}

	}

	@Override

	public boolean validatemobilenumber(String mblnum) {

	Pattern mb= Pattern.compile("[6-9]{1}[0-9]{9}");

	Matcher mid=mb.matcher(mblnum);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern number should be 10 digits ");

	return false;

	}

	}


	@Override

	public boolean validatealternatenumber(String ph) {

	Pattern p= Pattern.compile("[6-9]{1}[0-9]{9}");

	Matcher mid=p.matcher(ph);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern number should be 10 digits ");

	return false;

	}

	}

	@Override

	public boolean validateaddress(String add) {

	Pattern ad= Pattern.compile("[A-Za-z0-9.,]{5,25}");

	Matcher mid=ad.matcher(add);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern maximum should be 25 ");

	return false;

	}

	}

  @Override

	public boolean validateemail(String email) {
  
	Pattern em= Pattern.compile("[a-zA-z0-9/_.%+-]+@[a-zA-z]+.[a-zA-Z]{2,15}$");

	Matcher mid=em.matcher(email);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern ");

	return false;

	}
  }

  
  
  public boolean validateDate(String date) {

		Pattern ad= Pattern.compile("[0-9]+-[a-zA-z]+-[0-9]{2,15}$");

		Matcher mid=ad.matcher(date);

		if(mid.matches()) {

		return true;

		}

		else {

		System.out.println("please follow the pattern DD-MMM-YYYY ");

		return false;

		}

		}



@Override
public boolean validateNoOfDays(int noofdays) {
	
	String str1 = Integer.toString(noofdays); 
	Pattern ad= Pattern.compile("[0-9]{1,3}$");

	Matcher mid=ad.matcher(str1);

	if(mid.matches()) {

	return true;

	}

	else {

	System.out.println("please follow the pattern");

	return false;

	}

	
}




//////

@Override
public boolean adminValidation(String uName, String pass) {
	if(uName.equals("admin") && pass.equals("admin")) {
		return true;
		}
	else {
		System.out.println("Invalid Credentials");
		System.out.println("Please enter again");
		return false;
		}
}

@Override
public List<HotelBean> getAllHotels() throws HotelException {
	return hdao.getAllHotels();
}

@Override
public List<RoomDetailsBean> getAllRooms(String hid)   {
	
	return hdao.getAllRooms(hid);
}

@Override
public int addHotel(HotelBean hBean)   {
	
	return hdao.addHotel(hBean);
}

@Override
public HotelBean getHotelById(String htid)  {
	
	return hdao.getHotelById(htid);
}

@Override
public int updateCity(String city1, String htid){
	
	return hdao.updateCity(city1,htid);
}

@Override
public List<BookingBean> getHotelDetails(String hotelId) {
	
	return hdao.getHotelDetails(hotelId);
}

@Override
public List<BookingBean> getDetailsByDate(String bdate) {
	
	return hdao.getDetailsByDate(bdate);
}

@Override
public int radddetails(RoomDetailsBean rbean)   {
	
	return hdao.raddadetails(rbean);
}

@Override
public int deleteroom(String rid1) {
	
	return hdao.deleteroom(rid1);
}

@Override
public int updateRoomNumber(String rnum, String rid2) {
	
	return hdao. updateRoomNumber(rnum,rid2);
}

@Override
public int updateName(String hname, String htid) {
	
	return hdao. updateName(hname,htid);
}

@Override
public int updateAddress(String haddress, String htid) {
	
	return hdao. updateAddress(haddress,htid);
}

@Override
public int updateDesc(String hdesc, String htid) {

	return hdao.updateDesc(hdesc,htid);
}

@Override
public int updateRpn(String hrpn, String htid) {
	
	return hdao.updateRpn(hrpn,htid);
}

@Override
public int updatepn1(String hpn1, String htid) {

	return hdao.updatepn1(hpn1,htid);
}
@Override
public int updatepn2(String hpn2, String htid) {
	
	return hdao.updateepn2(hpn2,htid);
}

@Override
public int updateRating(String rating, String htid) {

	return hdao.updateRating(rating,htid);
}

@Override
public int updateRoomType(String rtype1, String rid2) {
	
	return hdao.updateRoomType(rtype1,rid2);
}

@Override
public int updateRoomPrice(int ppn, String rid2) {

	return hdao.updateRoomPrice(ppn,rid2);
}

@Override
public int updateRoomAvailability(String avl, String rid2) {

	return hdao.updateRoomAvailability(avl,rid2);
}
public boolean hotelVal(String hid) {
	
	Pattern pat = Pattern.compile("[h][0-9]{3}");
	Matcher mat = pat.matcher(hid);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid Hotel Id \nPlease Reenter");
		return false;
		
	}
	
	
}

public boolean roomVal(String hid) {
	
	Pattern pat = Pattern.compile("[r][0-9]{3}");
	Matcher mat = pat.matcher(hid);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid Room dsfdsf Id \nPlease Reenter");
		return false;
		
	}
}


public boolean cityVal(String city) {
	
	Pattern pat = Pattern.compile("[A-Z][a-z]{2,15}");
	Matcher mat = pat.matcher(city);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid City \nPlease Reenter");
		return false;
	}
}

public boolean nameVal(String hName) {
	
	Pattern pat = Pattern.compile("[A-Z][a-z]{2,20}");
	Matcher mat = pat.matcher(hName);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid Hotel Name \nPlease Reenter");
		return false;
	}
}

public boolean mnoVal(String phone1) {
	Pattern pat = Pattern.compile("[7-9][0-9]{9}");
	Matcher mat = pat.matcher(phone1);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid Mobile \nPlease Reenter");
		return false;
	}
}

public boolean emailVal(String email) {
	Pattern pat = Pattern.compile("[a-zA-z0-9/_.%+-]+@[a-zA-z]+.[a-zA-Z]{2,20}$");
	//System.out.println(email);
	//Pattern pat = Pattern.compile("[A-Z]{2,3}");
	Matcher mat = pat.matcher(email);
	//System.out.println("fd"+email);
	
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid Email....... \nPlease Reenter");
		return false;
	}
}

public boolean rateVal(String rate) {
	Pattern pat = Pattern.compile("[0-9]{1,10}");
	Matcher mat = pat.matcher(rate);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Inavalid City \nPlease Reenter");
		return false;
	}
}

public boolean dateVal(String bdate) {
	
	Pattern pat = Pattern.compile("[0-3][0-9][-][A-Za-z]{3}[-][0-9]{4}");
	Matcher mat = pat.matcher(bdate);
	if (mat.matches()){
		return true;
	}
	else {
		System.out.println("Please enter Date in 'DD-MMM-YYYY' format");
		return false;
	}
}

public boolean docase(int do1) {
	if(do1==1) {
		return true;
	}
	else {
		return false;
	}
}

@Override
public List<RoomDetailsBean> getRoomById(String rid2)   {
	//hdao = new DaoImpl();
	return hdao.getRoomById(rid2);
}










/////////




	}
