package com.hms.service;

import java.sql.SQLException;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomDetailsBean;
import com.hms.bean.UserBean;
import com.hms.exception.HotelException;

public interface IHotelService {

	public abstract boolean login(String user_id, String password) throws HotelException;

	public abstract BookingBean bookingStatus(String bookingId) throws HotelException;

	public abstract int register(UserBean ub) throws HotelException;

	public abstract List<HotelBean> AllHotel();

	public abstract List<RoomDetailsBean> availrooms(String hotelid) throws HotelException;

	public abstract int booking(BookingBean bb);

	public abstract void noofdays(String user_id,int noofdays,String hotelid) throws HotelException;

	public abstract int getbookingid() throws  HotelException;

	public abstract boolean useridcheck(String user_id)throws  HotelException;

	

	boolean validateemail(String email);

	boolean validateaddress(String add);

	boolean validatealternatenumber(String ph);

	boolean validatemobilenumber(String mblnum);

	boolean validateusername(String username);

	boolean validaterole(String role);

	boolean validatepassword(String password);

	boolean validateid(String user_id);
	
	boolean validateDate(String date);

	public abstract boolean getroomid(String roomid);

	public abstract boolean hotelidcheck(String hotelid);

	public abstract boolean validateNoOfDays(int noofdays);

	public abstract boolean hotelVal(String hId);

	public abstract boolean cityVal(String city);

	public abstract boolean nameVal(String hName);

	public abstract boolean mnoVal(String phone1);

	public abstract boolean emailVal(String email);

	public abstract boolean rateVal(String rate);

	public abstract boolean roomVal(String rid1);

	public abstract boolean dateVal(String bdate);

	public abstract List<RoomDetailsBean> getRoomById(String rid2);

	public abstract int updateRating(String rating, String htid);

	public abstract int updateRoomAvailability(String avl, String rid2);

	public abstract int updateRoomPrice(int ppn, String rid2);

	public abstract int updatepn2(String hpn2, String htid);

	public abstract int updatepn1(String hpn1, String htid);

	public abstract int updateRoomType(String rtype1, String rid2);

	public abstract int updateRpn(String hrpn, String htid);

	public abstract int updateDesc(String hdesc, String htid);

	public abstract int updateAddress(String haddress, String htid);

	public abstract int updateName(String hname, String htid);

	public abstract int updateRoomNumber(String rnum, String rid2);

	public abstract int deleteroom(String rid1);

	public abstract int radddetails(RoomDetailsBean rbean);

	public abstract List<BookingBean> getDetailsByDate(String bdate);

	public abstract List<BookingBean> getHotelDetails(String hotelId);

	public abstract int updateCity(String city1, String htid);

	public abstract HotelBean getHotelById(String htid);

	public abstract int addHotel(HotelBean hBean);

	public abstract List<RoomDetailsBean> getAllRooms(String hid);

	public abstract List<HotelBean> getAllHotels() throws SQLException, HotelException;

	public abstract boolean adminValidation(String uName, String pass);





	/*public abstract List<BookingBean> getAllBookings(String user_id);*/

}
