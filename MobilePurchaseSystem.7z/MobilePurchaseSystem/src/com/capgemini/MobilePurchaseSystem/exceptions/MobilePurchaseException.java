package com.capgemini.MobilePurchaseSystem.exceptions;

public class MobilePurchaseException extends Exception{
	public  MobilePurchaseException (String msg){
		super(msg);
	}
}
